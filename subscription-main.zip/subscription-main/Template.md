# @gkd-kit/subscription

`默认规则` 仅启用 `开屏广告` 一类规则, 其它所有规则均需用户手动打开

在 GKD 内添加以下链接即可使用此规则

```txt
https://s.gkd.li/
```

当前版本: v--VERSION--

当前订阅文件已适配 --APP_SIZE-- 个 APP, 共有 --GROUP_SIZE-- 规则组

查看 [适配 APP 列表](./AppList.md)

如何编写订阅/贡献此项目 -> [CONTRIBUTING.md](./CONTRIBUTING.md)

## 感谢以下开发者的贡献

![img](https://contrib.rocks/image?repo=gkd-kit/subscription&_v=--VERSION--)
