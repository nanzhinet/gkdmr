# 易校园

存在 1 规则组 - [cn.com.yunma.school.app](/src/apps/cn.com.yunma.school.app.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13175275)
- [快照-1](https://i.gkd.li/import/13177064)
- [快照-2](https://i.gkd.li/import/13198129)
- [快照-3](https://i.gkd.li/import/13179898)
