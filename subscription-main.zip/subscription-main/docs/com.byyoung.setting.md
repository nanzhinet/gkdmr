# 爱玩机工具箱

存在 1 规则组 - [com.byyoung.setting](/src/apps/com.byyoung.setting.ts)

## 忽略授权提示

默认禁用

- [快照-0](https://i.gkd.li/import/12829909)
