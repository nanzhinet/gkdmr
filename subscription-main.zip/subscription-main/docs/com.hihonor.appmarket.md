# 荣耀应用市场

存在 3 规则组 - [com.hihonor.appmarket](/src/apps/com.hihonor.appmarket.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13063815)
- [快照-1](https://i.gkd.li/import/13168440)

## 悬浮窗小广告

默认禁用

- [快照-0](https://i.gkd.li/import/13063928)

## 推送通知

默认禁用

- [快照-0](https://i.gkd.li/import/13073319)
