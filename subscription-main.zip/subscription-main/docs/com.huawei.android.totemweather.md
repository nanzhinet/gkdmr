# 华为天气

存在 3 规则组 - [com.huawei.android.totemweather](/src/apps/com.huawei.android.totemweather.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12928975)
- [快照-1](https://i.gkd.li/import/13226636)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/13218197)
- [快照-1](https://i.gkd.li/import/13259434)
- [快照-2](https://i.gkd.li/import/13521221)
- [快照-3](https://i.gkd.li/import/13787501)

## 顶部广告条

默认禁用

- [快照-0](https://i.gkd.li/import/13800100)
