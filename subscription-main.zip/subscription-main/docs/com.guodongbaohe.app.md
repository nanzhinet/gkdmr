# 果冻宝盒

存在 1 规则组 - [com.guodongbaohe.app](/src/apps/com.guodongbaohe.app.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13577877)
