# 湛庐阅读

存在 1 规则组 - [com.cheersedu.app](/src/apps/com.cheersedu.app.ts)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13315712)
