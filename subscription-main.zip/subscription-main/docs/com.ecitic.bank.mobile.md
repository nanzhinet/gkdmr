# 中信银行

存在 3 规则组 - [com.ecitic.bank.mobile](/src/apps/com.ecitic.bank.mobile.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12701217)
- [快照-1](https://i.gkd.li/import/12701250)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13402746)
- [快照-1](https://i.gkd.li/import/12701230)

## 请求开通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13399102)
