# HMS Core

存在 1 规则组 - [com.huawei.hwid](/src/apps/com.huawei.hwid.ts)

## 页面中间跳出广告

默认禁用

- [快照-0](https://i.gkd.li/import/12709068)
