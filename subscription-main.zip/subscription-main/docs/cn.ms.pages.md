# 飞鸟听书

存在 1 规则组 - [cn.ms.pages](/src/apps/cn.ms.pages.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13450787)
