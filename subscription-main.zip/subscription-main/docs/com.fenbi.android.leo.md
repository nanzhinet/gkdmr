# 小猿口算

存在 1 规则组 - [com.fenbi.android.leo](/src/apps/com.fenbi.android.leo.ts)

## 评分弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13226140)
