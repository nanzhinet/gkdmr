# 薄荷健康

存在 3 规则组 - [com.boohee.one](/src/apps/com.boohee.one.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12716918)

## 发现页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12716970)

## 请求开启通知权限弹窗

默认禁用 - 自动点击x按钮

- [快照-0](https://i.gkd.li/import/12716950)
