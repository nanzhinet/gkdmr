# 酷我音乐

存在 1 规则组 - [cn.kuwo.player](/src/apps/cn.kuwo.player.ts)

## 开屏、切屏广告

默认禁用

- [快照-0](https://i.gkd.li/import/12727887)
- [快照-1](https://i.gkd.li/import/12740634)
