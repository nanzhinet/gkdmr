# 讯飞AI学

存在 1 规则组 - [com.iflytek.aistudyclient.parentcontrol](/src/apps/com.iflytek.aistudyclient.parentcontrol.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12740402)
