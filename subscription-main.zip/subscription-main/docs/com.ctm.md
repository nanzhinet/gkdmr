# CTM Buddy

存在 2 规则组 - [com.ctm](/src/apps/com.ctm.ts)

## 浮窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13350575)

## 底部横幅广告

默认禁用

- [快照-0](https://i.gkd.li/import/13350612)
