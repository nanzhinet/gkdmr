# 大麦

存在 2 规则组 - [cn.damai](/src/apps/cn.damai.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12472623)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13627900)
