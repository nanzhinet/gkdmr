# 漫画人极速版

存在 1 规则组 - [com.jisu.manhua](/src/apps/com.jisu.manhua.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13688186)
