# 快牙

存在 1 规则组 - [com.dewmobile.kuaiya](/src/apps/com.dewmobile.kuaiya.ts)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/13477048)
