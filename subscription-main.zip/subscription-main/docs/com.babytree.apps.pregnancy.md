# 宝宝树孕育

存在 2 规则组 - [com.babytree.apps.pregnancy](/src/apps/com.babytree.apps.pregnancy.ts)

## 弹出广告(偶发)

默认禁用

- [快照-0](https://i.gkd.li/import/12614834)

## 首页右侧悬浮广告(偶发)

默认禁用

- [快照-0](https://i.gkd.li/import/12614838)
