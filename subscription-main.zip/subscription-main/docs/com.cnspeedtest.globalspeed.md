# 全球网测

存在 1 规则组 - [com.cnspeedtest.globalspeed](/src/apps/com.cnspeedtest.globalspeed.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12642345)
