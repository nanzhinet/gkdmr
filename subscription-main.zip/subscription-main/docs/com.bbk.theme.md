# i主题

存在 1 规则组 - [com.bbk.theme](/src/apps/com.bbk.theme.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13438571)
