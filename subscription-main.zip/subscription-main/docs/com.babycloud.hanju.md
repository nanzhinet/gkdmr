# 韩小圈

存在 2 规则组 - [com.babycloud.hanju](/src/apps/com.babycloud.hanju.ts)

## 局部广告

默认禁用

- [快照-0](https://i.gkd.li/import/13628282)
- [快照-1](https://i.gkd.li/import/13670721)
- [快照-2](https://i.gkd.li/import/13849929)

## 视频播放时的弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13800123)
