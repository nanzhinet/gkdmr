# YouTube Music

存在 1 规则组 - [com.google.android.apps.youtube.music](/src/apps/com.google.android.apps.youtube.music.ts)

## 播放界面广告

默认禁用

- [快照-0](https://i.gkd.li/import/13196056)
