# i 视频

存在 1 规则组 - [com.android.VideoPlayer](/src/apps/com.android.VideoPlayer.ts)

## 青少年模式

默认禁用

- [快照-0](https://i.gkd.li/import/13849807)
