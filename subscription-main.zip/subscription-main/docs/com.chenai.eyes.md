# 夜间模式

存在 1 规则组 - [com.chenai.eyes](/src/apps/com.chenai.eyes.ts)

## 全屏广告

默认禁用

- [快照-0](https://i.gkd.li/import/13698395)
