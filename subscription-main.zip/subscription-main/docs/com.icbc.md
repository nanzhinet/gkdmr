# 中国工商银行

存在 2 规则组 - [com.icbc](/src/apps/com.icbc.ts)

## 第一次启动提示

默认禁用

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13330431)
