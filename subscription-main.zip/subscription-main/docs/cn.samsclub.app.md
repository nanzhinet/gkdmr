# 山姆会员商店

存在 3 规则组 - [cn.samsclub.app](/src/apps/cn.samsclub.app.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13609106)

## 关闭「系统位置服务未打开」通知条

默认禁用

- [快照-0](https://i.gkd.li/import/13609113)

## 关闭「您有一张亲友卡待赠送」通知条

默认禁用

- [快照-0](https://i.gkd.li/import/13609113)
