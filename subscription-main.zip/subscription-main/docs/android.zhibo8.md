# 直播吧

存在 1 规则组 - [android.zhibo8](/src/apps/android.zhibo8.ts)

## 信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/12841134)
- [快照-1](https://i.gkd.li/import/12841135)
- [快照-2](https://i.gkd.li/import/13786148)
