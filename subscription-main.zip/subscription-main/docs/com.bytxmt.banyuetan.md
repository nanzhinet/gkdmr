# 半月谈

存在 1 规则组 - [com.bytxmt.banyuetan](/src/apps/com.bytxmt.banyuetan.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13166668)
