# 多麦

存在 1 规则组 - [com.duomai.duomai](/src/apps/com.duomai.duomai.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13350180)
