# 中银跨境GO

存在 1 规则组 - [com.bocop.cbsp](/src/apps/com.bocop.cbsp.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13445840)
