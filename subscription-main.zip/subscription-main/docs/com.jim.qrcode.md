# 随便扫

存在 1 规则组 - [com.jim.qrcode](/src/apps/com.jim.qrcode.ts)

## 顶部广告卡片

默认禁用 - 点击卡片右上角关闭按钮

- [快照-0](https://i.gkd.li/import/12606861)
- [快照-1](https://i.gkd.li/import/12606862)
