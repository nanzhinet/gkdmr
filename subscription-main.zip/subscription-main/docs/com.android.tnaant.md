# 蚂蚁加速器

存在 1 规则组 - [com.android.tnaant](/src/apps/com.android.tnaant.ts)

## 公告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13713449)
