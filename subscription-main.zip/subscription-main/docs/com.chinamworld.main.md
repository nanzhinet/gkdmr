# 中国建设银行

存在 1 规则组 - [com.chinamworld.main](/src/apps/com.chinamworld.main.ts)

## 我的页面-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12726961)
