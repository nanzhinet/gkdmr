# 联想浏览器HD

存在 2 规则组 - [com.lenovo.browser.hd](/src/apps/com.lenovo.browser.hd.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13401982)

## 请求通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13401980)
