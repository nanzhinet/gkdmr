# 高德地图

存在 5 规则组 - [com.autonavi.minimap](/src/apps/com.autonavi.minimap.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13379094)
- [快照-1](https://i.gkd.li/import/13379426)

## 截屏分享

默认禁用 - 关闭截屏时app弹出的分享弹窗

- [快照-0](https://i.gkd.li/import/13473388)

## 首页-地图页面上方消息提醒

默认禁用

- [快照-0](https://i.gkd.li/import/12642830)

## 首页-签到卡片

默认禁用 - 点击【x】

- [快照-0](https://i.gkd.li/import/12642842)
- [快照-1](https://i.gkd.li/import/12642845)
- [快照-2](https://i.gkd.li/import/12818770)
- [快照-3](https://i.gkd.li/import/13764540)

## 加油页面-优惠券弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12642857)
