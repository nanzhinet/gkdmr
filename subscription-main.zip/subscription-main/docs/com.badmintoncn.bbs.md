# 中羽在线

存在 1 规则组 - [com.badmintoncn.bbs](/src/apps/com.badmintoncn.bbs.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13635224)
