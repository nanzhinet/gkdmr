# 作业帮

存在 1 规则组 - [com.baidu.homework](/src/apps/com.baidu.homework.ts)

## 开屏广告
