# 凤凰新闻

存在 2 规则组 - [com.ifeng.news2](/src/apps/com.ifeng.news2.ts)

## 信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/12705500)
- [快照-1](https://i.gkd.li/import/12705508)
- [快照-2](https://i.gkd.li/import/12705511)
- [快照-3](https://i.gkd.li/import/12705518)
- [快照-4](https://i.gkd.li/import/12705520)
- [快照-5](https://i.gkd.li/import/12705505)

## 请求位置权限弹窗

默认禁用 - 自动点击取消

- [快照-0](https://i.gkd.li/import/12705531)
