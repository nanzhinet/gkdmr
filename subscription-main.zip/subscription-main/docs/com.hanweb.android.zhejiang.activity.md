# 浙里办

存在 1 规则组 - [com.hanweb.android.zhejiang.activity](/src/apps/com.hanweb.android.zhejiang.activity.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13402048)
- [快照-1](https://i.gkd.li/import/13520598)
- [快照-2](https://i.gkd.li/import/13521059)
