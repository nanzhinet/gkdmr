# 飞客

存在 1 规则组 - [com.ideal.flyerteacafes](/src/apps/com.ideal.flyerteacafes.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13466119)
