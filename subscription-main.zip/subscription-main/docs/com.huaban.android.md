# 花瓣

存在 1 规则组 - [com.huaban.android](/src/apps/com.huaban.android.ts)

## 更新提示-版本更新弹窗

默认禁用 - 点击不再提示

- [快照-0](https://i.gkd.li/import/13832253)
