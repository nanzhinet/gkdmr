# 华为音乐

存在 3 规则组 - [com.android.mediacenter](/src/apps/com.android.mediacenter.ts)

## 开屏广告

- [示例-0](https://github.com/gkd-kit/inspect/assets/38517192/6c34cd13-cfda-4462-99ed-2a2534a6fdf5)
- [示例-1](https://github.com/gkd-kit/inspect/assets/38517192/c71bb14d-cd1f-4f9e-8ee9-6a1e11e56901)

- [快照-0](https://i.gkd.li/import/12901417)
- [快照-1](https://i.gkd.li/import/12908742)

## VIP广告弹窗

默认禁用 - 点击底部圆形x图标关闭弹窗

- [示例-0](https://github.com/gkd-kit/inspect/assets/38517192/433dd71c-4fe5-41c9-a2da-dd3ac29f8dd4)

- [快照-0](https://i.gkd.li/import/12914026)

## 推荐广告卡片

默认禁用 - 点击卡片右上角[广告],点击不感兴趣[直接关闭]

- [示例-0](https://github.com/gkd-kit/inspect/assets/38517192/37ee4a9b-2518-41e6-8227-7b204ed1bf61)
- [示例-1](https://github.com/gkd-kit/inspect/assets/38517192/d098a194-80ff-49a1-b80e-191f7574a816)

- [快照-0](https://i.gkd.li/import/12914077)
- [快照-1](https://i.gkd.li/import/12914078)
