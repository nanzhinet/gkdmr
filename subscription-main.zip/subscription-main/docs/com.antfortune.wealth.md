# 蚂蚁财富

存在 1 规则组 - [com.antfortune.wealth](/src/apps/com.antfortune.wealth.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12776577)
