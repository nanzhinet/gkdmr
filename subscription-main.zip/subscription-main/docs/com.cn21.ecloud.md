# 天翼云盘

存在 2 规则组 - [com.cn21.ecloud](/src/apps/com.cn21.ecloud.ts)

## 首页弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12865481)
- [快照-1](https://i.gkd.li/import/12865488)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13399488)
