# 叮当快药

存在 1 规则组 - [com.ddsy.songyao](/src/apps/com.ddsy.songyao.ts)

## 优惠卷提示

默认禁用

- [快照-0](https://i.gkd.li/import/13048720)
