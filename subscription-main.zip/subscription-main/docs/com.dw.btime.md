# 亲宝宝

存在 3 规则组 - [com.dw.btime](/src/apps/com.dw.btime.ts)

## 应用内弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12889448)

## 应用内横幅

默认禁用

- [快照-0](https://i.gkd.li/import/12889450)

## 更新提示

默认禁用

- [快照-0](https://i.gkd.li/import/12911011)
