# 华为应用市场

存在 1 规则组 - [com.huawei.appmarket](/src/apps/com.huawei.appmarket.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13228520)
