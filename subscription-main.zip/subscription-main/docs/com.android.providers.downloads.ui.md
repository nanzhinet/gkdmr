# 下载管理

存在 1 规则组 - [com.android.providers.downloads.ui](/src/apps/com.android.providers.downloads.ui.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13631769)
