# 铁路12306

存在 1 规则组 - [com.MobileTicket](/src/apps/com.MobileTicket.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13196243)
