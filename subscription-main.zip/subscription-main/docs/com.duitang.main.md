# 堆糖

存在 3 规则组 - [com.duitang.main](/src/apps/com.duitang.main.ts)

## 青少年模式

默认禁用 - 关闭青少年模式提醒弹窗

- [快照-0](https://i.gkd.li/import/13202230)

## 首页-推荐浏览广告

默认禁用 - 关闭推荐浏览页面广告

- [快照-0](https://i.gkd.li/import/13202725)

## 去商店评分

默认禁用 - 点击[下次再说]

- [快照-0](https://i.gkd.li/import/13203217)
