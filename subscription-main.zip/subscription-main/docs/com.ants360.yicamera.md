# 小蚁摄像机

存在 1 规则组 - [com.ants360.yicamera](/src/apps/com.ants360.yicamera.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13463241)
- [快照-1](https://i.gkd.li/import/13543175)
