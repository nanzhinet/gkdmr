# OPPO软件商店

存在 1 规则组 - [com.heytap.market](/src/apps/com.heytap.market.ts)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13455965)
