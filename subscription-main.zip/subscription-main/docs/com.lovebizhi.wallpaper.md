# 爱壁纸

存在 1 规则组 - [com.lovebizhi.wallpaper](/src/apps/com.lovebizhi.wallpaper.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12859492)
