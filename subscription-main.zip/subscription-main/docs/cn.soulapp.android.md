# Soul

存在 5 规则组 - [cn.soulapp.android](/src/apps/cn.soulapp.android.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12833280)
- [快照-1](https://i.gkd.li/import/12850094)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12834093)

## 广场页卡片广告

默认禁用

- [快照-0](https://i.gkd.li/import/12838000)

## app评分

默认禁用

- [快照-0](https://i.gkd.li/import/13425057)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13693361)
