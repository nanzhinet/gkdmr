# 剧多多

存在 1 规则组 - [com.juduoduo.app](/src/apps/com.juduoduo.app.ts)

## 弹窗广告

默认禁用 - 快手广告SDK

- [快照-0](https://i.gkd.li/import/13705650)
- [快照-1](https://i.gkd.li/import/13705662)
