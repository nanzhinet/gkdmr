# Edifier Connect

存在 1 规则组 - [com.edifier.edifierconnect](/src/apps/com.edifier.edifierconnect.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13413809)
