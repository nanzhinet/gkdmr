# 百分网游戏盒子

存在 2 规则组 - [com.byfen.market](/src/apps/com.byfen.market.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13298944)
- [快照-1](https://i.gkd.li/import/13800021)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13801613)
