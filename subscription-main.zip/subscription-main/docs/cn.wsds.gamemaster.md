# 迅游手游加速器

存在 2 规则组 - [cn.wsds.gamemaster](/src/apps/cn.wsds.gamemaster.ts)

## 开屏广告

点击跳过

- [快照-0](https://i.gkd.li/import/13930391)

## 分段广告-卡片广告

默认禁用 - 点击X-点击不感兴趣

- [快照-0](https://i.gkd.li/import/13930398)
- [快照-1](https://i.gkd.li/import/13930399)
