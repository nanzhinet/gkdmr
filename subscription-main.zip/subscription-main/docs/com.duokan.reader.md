# 多看

存在 4 规则组 - [com.duokan.reader](/src/apps/com.duokan.reader.ts)

## 首页-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13248773)

## 小说推荐弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13413412)

## 小说页广告

默认禁用 - 小说页面下方出现的条形广告

- [快照-0](https://i.gkd.li/import/13497902)

## 小说页全屏卡片广告

默认禁用 - 点击关闭和确定按钮

- [快照-0](https://i.gkd.li/import/13498048)
- [快照-1](https://i.gkd.li/import/13497990)
