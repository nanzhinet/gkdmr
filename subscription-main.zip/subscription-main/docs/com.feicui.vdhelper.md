# 翡翠视频

存在 1 规则组 - [com.feicui.vdhelper](/src/apps/com.feicui.vdhelper.ts)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12700749)
- [快照-1](https://i.gkd.li/import/12700759)
- [快照-2](https://i.gkd.li/import/12700800)
- [快照-3](https://i.gkd.li/import/12700837)
- [快照-4](https://i.gkd.li/import/12700848)
