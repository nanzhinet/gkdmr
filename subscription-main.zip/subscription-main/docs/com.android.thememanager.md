# miui主题壁纸

存在 2 规则组 - [com.android.thememanager](/src/apps/com.android.thememanager.ts)

## 主题详情底部广告

默认禁用 - 注意如果使用ADB禁用了MIUI广告组件,点击此按钮会无反应,可关闭此规则,避免过多相同点击记录

- [快照-0](https://i.gkd.li/import/13227330)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13215038)
