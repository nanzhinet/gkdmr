# 影视工场

存在 1 规则组 - [com.flttrade.flt1064trade.gong](/src/apps/com.flttrade.flt1064trade.gong.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13759472)
- [快照-1](https://i.gkd.li/import/13798323)
- [快照-2](https://i.gkd.li/import/13798327)
