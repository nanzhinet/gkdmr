# 阿里巴巴

存在 2 规则组 - [com.alibaba.wireless](/src/apps/com.alibaba.wireless.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12684422)
- [快照-1](https://i.gkd.li/import/12684426)

## 首页-弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13683509)
- [快照-1](https://i.gkd.li/import/13683510)
