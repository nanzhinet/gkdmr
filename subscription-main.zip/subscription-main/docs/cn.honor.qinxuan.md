# 荣耀亲选

存在 1 规则组 - [cn.honor.qinxuan](/src/apps/cn.honor.qinxuan.ts)

## 全屏广告-首页广告弹窗

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13930613)
