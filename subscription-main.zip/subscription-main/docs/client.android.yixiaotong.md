# 乐校通

存在 3 规则组 - [client.android.yixiaotong](/src/apps/client.android.yixiaotong.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13055837)
- [快照-1](https://i.gkd.li/import/13060116)
- [快照-2](https://i.gkd.li/import/13625511)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/13451010)
- [快照-1](https://i.gkd.li/import/13450887)

## 底部卡片广告

默认禁用

- [快照-0](https://i.gkd.li/import/13448963)
