# 光大银行

存在 2 规则组 - [com.cebbank.mobile.cemb](/src/apps/com.cebbank.mobile.cemb.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12727241)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12727248)
- [快照-1](https://i.gkd.li/import/13471080)
