# 解压专家

存在 2 规则组 - [com.fileunzip.zxwknight](/src/apps/com.fileunzip.zxwknight.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13328194)
- [快照-1](https://i.gkd.li/import/13391833)

## 升级专业版弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13328212)
