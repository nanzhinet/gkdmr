# 华为运动健康

存在 5 规则组 - [com.huawei.health](/src/apps/com.huawei.health.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12667766)
- [快照-1](https://i.gkd.li/import/13215012)
- [快照-2](https://i.gkd.li/import/13228290)

## “我的”页会员广告

默认禁用

- [快照-0](https://i.gkd.li/import/12667814)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13546292)

## 请求开启个性化推荐弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13546292)

## 底部横幅广告

默认禁用

- [快照-0](https://i.gkd.li/import/13587206)
