# 安兔兔评测

存在 1 规则组 - [com.antutu.ABenchMark](/src/apps/com.antutu.ABenchMark.ts)

## 广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/13234012)
