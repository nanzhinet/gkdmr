# 多系统工具箱

存在 1 规则组 - [com.example.ourom](/src/apps/com.example.ourom.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13625406)
