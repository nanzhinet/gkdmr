# 党建头条

存在 1 规则组 - [com.djttw.news](/src/apps/com.djttw.news.ts)

## 开屏广告

- [示例-0](https://m.gkd.li/6328439/3434673a-67eb-4c81-8fd3-c69dfa8d00db)

- [快照-0](https://i.gkd.li/import/13359665)
