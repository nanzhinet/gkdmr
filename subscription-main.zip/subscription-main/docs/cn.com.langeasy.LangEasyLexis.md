# 不背单词

存在 2 规则组 - [cn.com.langeasy.LangEasyLexis](/src/apps/cn.com.langeasy.LangEasyLexis.ts)

## 自动签到

默认禁用

- [快照-0](https://i.gkd.li/import/13610321)

## 右下角弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13759025)
