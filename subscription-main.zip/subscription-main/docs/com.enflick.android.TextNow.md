# TextNow

存在 2 规则组 - [com.enflick.android.TextNow](/src/apps/com.enflick.android.TextNow.ts)

## 设为默认应用提示

默认禁用

- [快照-0](https://i.gkd.li/import/13630460)
- [快照-1](https://i.gkd.li/import/13630463)

## 通知/链接蓝牙附件设备 权限申请

默认禁用

- [快照-0](https://i.gkd.li/import/13657279)
- [快照-1](https://i.gkd.li/import/13657280)
