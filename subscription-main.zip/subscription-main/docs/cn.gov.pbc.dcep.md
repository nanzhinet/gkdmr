# 数字人民币

存在 1 规则组 - [cn.gov.pbc.dcep](/src/apps/cn.gov.pbc.dcep.ts)

## 更新提示

默认禁用

- [快照-0](https://i.gkd.li/import/13840408)
