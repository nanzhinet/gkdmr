# 天猫精灵

存在 1 规则组 - [com.alibaba.ailabs.tg](/src/apps/com.alibaba.ailabs.tg.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13296332)
