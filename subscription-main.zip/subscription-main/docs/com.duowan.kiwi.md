# 虎牙直播

存在 5 规则组 - [com.duowan.kiwi](/src/apps/com.duowan.kiwi.ts)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12908790)

## 直播间悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/12901045)
- [快照-1](https://i.gkd.li/import/12901044)
- [快照-2](https://i.gkd.li/import/13395604)
- [快照-3](https://i.gkd.li/import/13395606)
- [快照-4](https://i.gkd.li/import/13417245)
- [快照-5](https://i.gkd.li/import/13401266)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13440833)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13625453)

## root提示

默认禁用 - 您的设备已经被ROOT

- [快照-0](https://i.gkd.li/import/13536744)
