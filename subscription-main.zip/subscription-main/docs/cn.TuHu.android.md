# 途虎养车

存在 2 规则组 - [cn.TuHu.android](/src/apps/cn.TuHu.android.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13228818)

## 请求通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13228796)
- [快照-1](https://i.gkd.li/import/13256535)
