# 东方财富

存在 2 规则组 - [com.eastmoney.android.berlin](/src/apps/com.eastmoney.android.berlin.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706070)
- [快照-1](https://i.gkd.li/import/13399156)

## 请求通知权限提示信息

默认禁用

- [快照-0](https://i.gkd.li/import/12706065)
