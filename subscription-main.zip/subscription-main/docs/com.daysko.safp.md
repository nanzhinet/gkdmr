# 7天澳門統考

存在 3 规则组 - [com.daysko.safp](/src/apps/com.daysko.safp.ts)

## 谷歌广告-全屏广告

默认禁用

- [快照-0](https://i.gkd.li/import/12642909)
- [快照-1](https://i.gkd.li/import/12643316)
- [快照-2](https://i.gkd.li/import/12643032)
- [快照-3](https://i.gkd.li/import/12643039)
- [快照-4](https://i.gkd.li/import/12643246)

## 谷歌广告-视频广告

默认禁用 - 点击跳过视频-点击关闭按钮

- [快照-0](https://i.gkd.li/import/12668269)
- [快照-1](https://i.gkd.li/import/12642913)
- [快照-2](https://i.gkd.li/import/12642932)
- [快照-3](https://i.gkd.li/import/12642952)
- [快照-4](https://i.gkd.li/import/12668298)
- [快照-5](https://i.gkd.li/import/12642983)

## 谷歌广告-页面底部广告

默认禁用

- [快照-0](https://i.gkd.li/import/12642993)
- [快照-1](https://i.gkd.li/import/12643229)
- [快照-2](https://i.gkd.li/import/12643001)
