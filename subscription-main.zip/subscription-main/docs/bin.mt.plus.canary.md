# MT管理器Pro

存在 1 规则组 - [bin.mt.plus.canary](/src/apps/bin.mt.plus.canary.ts)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13561226)
