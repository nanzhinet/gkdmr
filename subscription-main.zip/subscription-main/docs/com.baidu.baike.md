# 百度百科

存在 1 规则组 - [com.baidu.baike](/src/apps/com.baidu.baike.ts)

## 请求通知权限弹窗

默认禁用 - 自动点击【不允许】

- [快照-0](https://i.gkd.li/import/12755717)
