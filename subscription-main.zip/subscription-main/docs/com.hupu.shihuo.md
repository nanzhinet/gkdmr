# 识货

存在 2 规则组 - [com.hupu.shihuo](/src/apps/com.hupu.shihuo.ts)

## 请求消息通知

默认禁用

- [快照-0](https://i.gkd.li/import/13704887)

## 广告弹窗

默认禁用 - 点击左上角x关闭

- [快照-0](https://i.gkd.li/import/13115664)
