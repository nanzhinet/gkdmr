# OMOFUN

存在 3 规则组 - [com.cyl.musiccy.ou](/src/apps/com.cyl.musiccy.ou.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12775918)
- [快照-1](https://i.gkd.li/import/12775926)
- [快照-2](https://i.gkd.li/import/13063151)
- [快照-3](https://i.gkd.li/import/13063246)
- [快照-4](https://i.gkd.li/import/13071599)
- [快照-5](https://i.gkd.li/import/12775919)

## 首页通知

默认禁用

- [快照-0](https://i.gkd.li/import/13063206)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12775922)
- [快照-1](https://i.gkd.li/import/13063222)
- [快照-2](https://i.gkd.li/import/12775923)
- [快照-3](https://i.gkd.li/import/13800051)
- [快照-4](https://i.gkd.li/import/13759345)
- [快照-5](https://i.gkd.li/import/12775925)
- [快照-6](https://i.gkd.li/import/12775924)
- [快照-7](https://i.gkd.li/import/12775921)
- [快照-8](https://i.gkd.li/import/12776903)
- [快照-9](https://i.gkd.li/import/12789928)
- [快照-10](https://i.gkd.li/import/13215476)
- [快照-11](https://i.gkd.li/import/13071595)
- [快照-12](https://i.gkd.li/import/13063249)
- [快照-13](https://i.gkd.li/import/13422363)
