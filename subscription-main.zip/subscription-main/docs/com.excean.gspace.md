# OurPlay

存在 1 规则组 - [com.excean.gspace](/src/apps/com.excean.gspace.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13302890)
- [快照-1](https://i.gkd.li/import/13447122)
