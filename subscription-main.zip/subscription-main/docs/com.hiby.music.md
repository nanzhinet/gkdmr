# 海贝音乐

存在 1 规则组 - [com.hiby.music](/src/apps/com.hiby.music.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13293606)
