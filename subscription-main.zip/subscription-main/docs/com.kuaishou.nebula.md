# 快手极速版

存在 1 规则组 - [com.kuaishou.nebula](/src/apps/com.kuaishou.nebula.ts)

## 青少年弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13196316)
