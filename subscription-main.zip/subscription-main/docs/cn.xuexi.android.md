# 学习强国

存在 2 规则组 - [cn.xuexi.android](/src/apps/cn.xuexi.android.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12715139)

## 请求开启通知权限提示信息

默认禁用 - 自动点击x按钮

- [快照-0](https://i.gkd.li/import/12715160)
