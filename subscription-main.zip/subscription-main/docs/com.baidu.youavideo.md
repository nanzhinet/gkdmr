# 一刻相册

存在 8 规则组 - [com.baidu.youavideo](/src/apps/com.baidu.youavideo.ts)

## 软件升级提醒

默认禁用

- [快照-0](https://i.gkd.li/import/12597916)

## 悬浮窗

默认禁用 - 关闭广告悬浮窗

- [快照-0](https://i.gkd.li/import/12970088)

## 评价

默认禁用 - 点击下次再说

- [快照-0](https://i.gkd.li/import/12970094)

## 会员充值提示

默认禁用 - 点击x关闭充值提示

- [快照-0](https://i.gkd.li/import/12970094)

## 弹窗广告

默认禁用 - 点击x关闭广告提示

- [快照-0](https://i.gkd.li/import/13048700)

## 请求开启通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13413819)

## 照片-底部浮窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13711475)

## 局部广告-广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/13874124)
