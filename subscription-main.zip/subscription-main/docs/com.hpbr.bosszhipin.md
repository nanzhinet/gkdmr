# BOSS直聘

存在 1 规则组 - [com.hpbr.bosszhipin](/src/apps/com.hpbr.bosszhipin.ts)

## 通知权限授权弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13440781)
- [快照-1](https://i.gkd.li/import/13623476)
