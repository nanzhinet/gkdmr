# 网速管家极速版

存在 2 规则组 - [cn.speedtest.lite](/src/apps/cn.speedtest.lite.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12715483)

## 新人专享优惠弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12715511)
