# 无忧行

存在 2 规则组 - [com.cmi.jegotrip](/src/apps/com.cmi.jegotrip.ts)

## 应用内广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13631904)

## 请求定位权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13232766)
