# 深(新)度搜索

存在 1 规则组 - [com.bz.yilianlife.sd](/src/apps/com.bz.yilianlife.sd.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13766176)
