# APKPure

存在 4 规则组 - [com.apkpure.aegon](/src/apps/com.apkpure.aegon.ts)

## 热门推荐关闭

默认禁用 - 关闭应用推广

- [快照-0](https://i.gkd.li/import/13466647)

## 更新与已安装界面-查看更多

默认禁用 - 在更新界面自动点击查看更多按钮，展开所有应用

- [快照-0](https://i.gkd.li/import/13466329)

## 更新界面-软件推荐

默认禁用

- [快照-0](https://i.gkd.li/import/13466329)
- [快照-1](https://i.gkd.li/import/13466610)

## 添加桌面快捷方式

默认禁用 - 下次添加

- [快照-0](https://i.gkd.li/import/13416401)
