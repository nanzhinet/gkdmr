# 喵上漫画

存在 4 规则组 - [com.aster.zhbj](/src/apps/com.aster.zhbj.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12981243)
- [快照-1](https://i.gkd.li/import/13029855)
- [快照-2](https://i.gkd.li/import/13043320)
- [快照-3](https://i.gkd.li/import/13043344)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12984767)
- [快照-1](https://i.gkd.li/import/12998908)
- [快照-2](https://i.gkd.li/import/12777325)
- [快照-3](https://i.gkd.li/import/13029880)
- [快照-4](https://i.gkd.li/import/12872249)
- [快照-5](https://i.gkd.li/import/12903062)
- [快照-6](https://i.gkd.li/import/12996953)
- [快照-7](https://i.gkd.li/import/13003644)

## 视频广告

默认禁用

- [快照-0](https://i.gkd.li/import/13348662)

## 看视频解锁任意读弹窗

默认禁用 - 自动点击【我拒绝】

- [快照-0](https://i.gkd.li/import/13348635)
