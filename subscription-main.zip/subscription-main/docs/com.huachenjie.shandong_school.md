# 闪动校园

存在 1 规则组 - [com.huachenjie.shandong_school](/src/apps/com.huachenjie.shandong_school.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12922866)
- [快照-1](https://i.gkd.li/import/13031192)
