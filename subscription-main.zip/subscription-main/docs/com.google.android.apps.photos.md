# 谷歌相册

存在 2 规则组 - [com.google.android.apps.photos](/src/apps/com.google.android.apps.photos.ts)

## 更新提示-取消更新

默认禁用 - 点击[以后再说]

- [快照-0](https://i.gkd.li/import/13218940)

## 全屏广告-优惠提示

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13774247)
