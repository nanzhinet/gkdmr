# 观察者

存在 1 规则组 - [cn.guancha.app](/src/apps/cn.guancha.app.ts)

## 开屏广告

点击开屏右上角“跳过”按钮

- [快照-0](https://i.gkd.li/import/12907063)
