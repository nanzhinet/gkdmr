# 猴子分身

存在 1 规则组 - [cn.chuci.and.wkfenshen](/src/apps/cn.chuci.and.wkfenshen.ts)

## 购买会员弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13226988)
