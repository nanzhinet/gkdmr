# 稀土掘金

存在 1 规则组 - [com.daimajia.gold](/src/apps/com.daimajia.gold.ts)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13498703)
