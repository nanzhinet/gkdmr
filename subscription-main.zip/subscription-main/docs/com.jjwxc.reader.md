# 晋江小说阅读

存在 1 规则组 - [com.jjwxc.reader](/src/apps/com.jjwxc.reader.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13662836)
