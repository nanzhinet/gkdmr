# 小卖部逆袭记

存在 1 规则组 - [com.dz.xmbnxj](/src/apps/com.dz.xmbnxj.ts)

## 底部卡片广告

默认禁用

- [示例-0](https://m.gkd.li/99116490/40d3c3c9-9443-4c71-9a98-69efa38f8bfd)

- [快照-0](https://i.gkd.li/import/13399232)
