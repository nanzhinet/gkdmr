# 库街区

存在 1 规则组 - [com.kurogame.kjq](/src/apps/com.kurogame.kjq.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12836250)
- [快照-1](https://i.gkd.li/import/12836248)
