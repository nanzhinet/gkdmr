# 支付宝

存在 7 规则组 - [com.eg.android.AlipayGphone](/src/apps/com.eg.android.AlipayGphone.ts)

## 更新提示-关闭花呗升级弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12737055)
- [快照-1](https://i.gkd.li/import/13183946)
- [快照-2](https://i.gkd.li/import/12826077)
- [快照-3](https://i.gkd.li/import/12915864)
- [快照-4](https://i.gkd.li/import/13631362)
- [快照-5](https://i.gkd.li/import/13857535)

## 定位提示-请求定位权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12792688)

## 通知提示-请求通知弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13194955)
- [快照-1](https://i.gkd.li/import/13669620)

## 更新提示-版本更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13327095)
- [快照-1](https://i.gkd.li/import/13490805)
- [快照-2](https://i.gkd.li/import/13580594)
- [快照-3](https://i.gkd.li/import/13490797)

## 设置支付宝小组件

默认禁用 - 点击关闭

- [快照-0](https://i.gkd.li/import/13327349)

## 小程序-12306

默认禁用

- [快照-0](https://i.gkd.li/import/13763314)
- [快照-1](https://i.gkd.li/import/13763315)

## 全屏广告-借呗消费信贷协议

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13915022)
