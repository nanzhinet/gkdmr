# 铁塔换电

存在 1 规则组 - [com.chinatower.tthd](/src/apps/com.chinatower.tthd.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13694901)
