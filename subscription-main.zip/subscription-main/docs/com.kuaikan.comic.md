# 快看漫画

存在 2 规则组 - [com.kuaikan.comic](/src/apps/com.kuaikan.comic.ts)

## 关闭青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12565678)

## 漫画界面-底部广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12910268)
