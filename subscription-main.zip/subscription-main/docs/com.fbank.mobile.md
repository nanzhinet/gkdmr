# 富民银行

存在 1 规则组 - [com.fbank.mobile](/src/apps/com.fbank.mobile.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13797434)
