# 微店

存在 1 规则组 - [com.koudai.weidian.buyer](/src/apps/com.koudai.weidian.buyer.ts)

## 首页红包弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13646151)
