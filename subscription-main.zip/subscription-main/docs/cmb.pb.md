# 招商银行

存在 2 规则组 - [cmb.pb](/src/apps/cmb.pb.ts)

## 朝朝宝-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706022)

## 定位提示-请求定位权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706029)
- [快照-1](https://i.gkd.li/import/13248893)
- [快照-2](https://i.gkd.li/import/13897345)
