# 央视频

存在 1 规则组 - [com.cctv.yangshipin.app.androidp](/src/apps/com.cctv.yangshipin.app.androidp.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12774838)
