# 手机知网

存在 1 规则组 - [com.cnki.client](/src/apps/com.cnki.client.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12854857)
