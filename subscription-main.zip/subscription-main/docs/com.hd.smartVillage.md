# 恒大智慧社区

存在 2 规则组 - [com.hd.smartVillage](/src/apps/com.hd.smartVillage.ts)

## 关闭开启通知弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13223669)
- [快照-1](https://i.gkd.li/import/13293000)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13223642)
