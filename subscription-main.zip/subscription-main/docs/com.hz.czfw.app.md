# 开吧

存在 1 规则组 - [com.hz.czfw.app](/src/apps/com.hz.czfw.app.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13228766)
