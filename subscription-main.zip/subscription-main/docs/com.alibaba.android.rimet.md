# 钉钉

存在 5 规则组 - [com.alibaba.android.rimet](/src/apps/com.alibaba.android.rimet.ts)

## 消息列表上方广告

默认禁用

- [快照-0](https://i.gkd.li/import/13325125)

## 文件即将过期提示

默认禁用

- [快照-0](https://i.gkd.li/import/13325125)

## 自动点击原图

默认禁用

- [快照-0](https://i.gkd.li/import/13309648)
- [快照-1](https://i.gkd.li/import/13309845)

## 版本更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13402478)
- [快照-1](https://i.gkd.li/import/13772151)

## 扫码自动登录桌面版

默认禁用

- [快照-0](https://i.gkd.li/import/13433981)
