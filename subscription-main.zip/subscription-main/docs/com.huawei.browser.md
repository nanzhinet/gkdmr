# 华为浏览器

存在 2 规则组 - [com.huawei.browser](/src/apps/com.huawei.browser.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12681995)
- [快照-1](https://i.gkd.li/import/13403785)

## 开启资讯通知弹窗

默认禁用 - 关闭资讯通知后，总是弹窗让打开

- [示例-0](https://m.gkd.li/87047583/3982b64a-15a7-4c0c-b179-2ed82d6ea18e)

- [快照-0](https://i.gkd.li/import/13692404)
