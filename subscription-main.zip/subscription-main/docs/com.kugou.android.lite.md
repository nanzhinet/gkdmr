# 酷狗概念版

存在 1 规则组 - [com.kugou.android.lite](/src/apps/com.kugou.android.lite.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13324363)
- [快照-1](https://i.gkd.li/import/13318737)
- [快照-2](https://i.gkd.li/import/12919282)
