# Keep

存在 5 规则组 - [com.gotokeep.keep](/src/apps/com.gotokeep.keep.ts)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706097)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706102)
- [快照-1](https://i.gkd.li/import/13761641)

## 首页信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/12706115)

## 运动购页面-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706111)
- [快照-1](https://i.gkd.li/import/13766358)

## 请求开启通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13761671)
