# AC匿名版

存在 2 规则组 - [com.dfsly.bbs](/src/apps/com.dfsly.bbs.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13330351)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13343675)
- [快照-1](https://i.gkd.li/import/13335135)
- [快照-2](https://i.gkd.li/import/13335316)
