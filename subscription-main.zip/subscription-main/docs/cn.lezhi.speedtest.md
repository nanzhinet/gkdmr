# 网速管家

存在 2 规则组 - [cn.lezhi.speedtest](/src/apps/cn.lezhi.speedtest.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13544242)
- [快照-1](https://i.gkd.li/import/13626049)
- [快照-2](https://i.gkd.li/import/13885906)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12727619)
