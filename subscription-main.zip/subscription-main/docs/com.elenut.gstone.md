# 集石

存在 1 规则组 - [com.elenut.gstone](/src/apps/com.elenut.gstone.ts)

## 开屏广告

- [示例-0](https://m.gkd.li/47232102/193c811c-88cf-4952-b367-95a3ef9a1d8c)

- [快照-0](https://i.gkd.li/import/13521239)
