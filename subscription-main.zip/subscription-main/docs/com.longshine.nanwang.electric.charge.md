# 顺易充

存在 1 规则组 - [com.longshine.nanwang.electric.charge](/src/apps/com.longshine.nanwang.electric.charge.ts)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12700011)
