# 掌上生活

存在 4 规则组 - [com.cmbchina.ccd.pluto.cmbActivity](/src/apps/com.cmbchina.ccd.pluto.cmbActivity.ts)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/12647025)
- [快照-1](https://i.gkd.li/import/12727203)
- [快照-2](https://i.gkd.li/import/13345771)

## 首页弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12647000)
- [快照-1](https://i.gkd.li/import/13360282)

## 右侧悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/12647039)
- [快照-1](https://i.gkd.li/import/12647052)
- [快照-2](https://i.gkd.li/import/12647127)
- [快照-3](https://i.gkd.li/import/13402782)

## 消息页面-通知开关

默认禁用 - 点击x按钮，不开启系统通知

- [快照-0](https://i.gkd.li/import/12647068)
