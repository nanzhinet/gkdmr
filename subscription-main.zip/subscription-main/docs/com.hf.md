# 中国天气

存在 1 规则组 - [com.hf](/src/apps/com.hf.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13477032)
- [快照-1](https://i.gkd.li/import/13625328)
