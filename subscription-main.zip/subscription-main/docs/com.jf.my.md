# 蜜源

存在 2 规则组 - [com.jf.my](/src/apps/com.jf.my.ts)

## 版本升级弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12838034)
- [快照-1](https://i.gkd.li/import/12840591)
- [快照-2](https://i.gkd.li/import/13786867)

## 首页-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12840619)
