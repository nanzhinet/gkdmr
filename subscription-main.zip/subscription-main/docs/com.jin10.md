# 金十数据

存在 4 规则组 - [com.jin10](/src/apps/com.jin10.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706043)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706045)

## 快讯页面-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12706047)

## 会员页面-顶部广告

默认禁用

- [快照-0](https://i.gkd.li/import/12706051)
