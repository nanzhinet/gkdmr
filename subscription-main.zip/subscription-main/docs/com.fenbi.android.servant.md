# 粉笔

存在 1 规则组 - [com.fenbi.android.servant](/src/apps/com.fenbi.android.servant.ts)

## 升级弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12999725)
