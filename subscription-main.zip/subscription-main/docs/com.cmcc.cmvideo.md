# 咪咕视频

存在 5 规则组 - [com.cmcc.cmvideo](/src/apps/com.cmcc.cmvideo.ts)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12498307)

## 右下角小广告

默认禁用

- [快照-0](https://i.gkd.li/import/12498315)

## 版本更新提示

默认禁用

- [快照-0](https://i.gkd.li/import/13276116)

## 推送通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13276127)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13276111)
- [快照-1](https://i.gkd.li/import/13276122)
