# 斗鱼

存在 3 规则组 - [air.tv.douyu.android](/src/apps/air.tv.douyu.android.ts)

## 青少年模式

默认禁用 - 关闭青少年模式提醒弹窗

- [快照-0](https://i.gkd.li/import/12472598)

## 新版本弹窗

默认禁用

## 直播间广告

默认禁用

- [快照-0](https://i.gkd.li/import/12892825)
- [快照-1](https://i.gkd.li/import/13037239)
- [快照-2](https://i.gkd.li/import/12892825)
- [快照-3](https://i.gkd.li/import/13056107)
- [快照-4](https://i.gkd.li/import/13056107)
- [快照-5](https://i.gkd.li/import/13056107)
