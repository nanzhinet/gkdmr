# Bimmer控制器

存在 1 规则组 - [com.bmw.app.bundle](/src/apps/com.bmw.app.bundle.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13328341)
