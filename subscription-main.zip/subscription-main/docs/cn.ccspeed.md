# CC加速器

存在 1 规则组 - [cn.ccspeed](/src/apps/cn.ccspeed.ts)

## 加速页-分享抽奖浮窗

默认禁用

- [快照-0](https://i.gkd.li/import/13539299)
