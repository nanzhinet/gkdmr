# ES文件浏览器

存在 2 规则组 - [com.estrongs.android.pop](/src/apps/com.estrongs.android.pop.ts)

## 全屏广告

默认禁用

- [快照-0](https://i.gkd.li/import/12509667)
- [快照-1](https://i.gkd.li/import/12509669)

## 局部广告

默认禁用

- [快照-0](https://i.gkd.li/import/12674919)
- [快照-1](https://i.gkd.li/import/12818281)
- [快照-2](https://i.gkd.li/import/13842299)
