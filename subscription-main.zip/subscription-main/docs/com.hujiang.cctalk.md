# CCtalk

存在 1 规则组 - [com.hujiang.cctalk](/src/apps/com.hujiang.cctalk.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13406032)
