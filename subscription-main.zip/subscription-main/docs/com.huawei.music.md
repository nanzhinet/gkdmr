# 华为音乐

存在 7 规则组 - [com.huawei.music](/src/apps/com.huawei.music.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12745222)

## 广告反馈下拉窗

默认禁用

- [快照-0](https://i.gkd.li/import/13067574)
- [快照-1](https://i.gkd.li/import/13067572)
- [快照-2](https://i.gkd.li/import/13067571)
- [快照-3](https://i.gkd.li/import/13067659)
- [快照-4](https://i.gkd.li/import/13067665)
- [快照-5](https://i.gkd.li/import/13067820)

## 播放界面直播浮窗

默认禁用

- [快照-0](https://i.gkd.li/import/13067649)

## 播放（音乐、视频）页面广告

默认禁用

- [快照-0](https://i.gkd.li/import/13067956)
- [快照-1](https://i.gkd.li/import/13067978)
- [快照-2](https://i.gkd.li/import/13067387)

## 评论区广告

默认禁用

- [快照-0](https://i.gkd.li/import/13067937)

## 视频播放页广告反馈

默认禁用

- [快照-0](https://i.gkd.li/import/13067986)
- [快照-1](https://i.gkd.li/import/13067981)

## 播放器上滑广告

默认禁用

- [快照-0](https://i.gkd.li/import/13068935)
- [快照-1](https://i.gkd.li/import/13194163)
- [快照-2](https://i.gkd.li/import/13263590)
