# 广东税务

存在 1 规则组 - [com.example.servyouappzhuhai](/src/apps/com.example.servyouappzhuhai.ts)

## 通知权限授权弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13440721)
