# 智慧树

存在 2 规则组 - [com.hyww.wisdomtree](/src/apps/com.hyww.wisdomtree.ts)

## 全屏广告

默认禁用

- [快照-0](https://i.gkd.li/import/13799876)
- [快照-1](https://i.gkd.li/import/13852024)

## 局部广告

默认禁用

- [快照-0](https://i.gkd.li/import/13852023)
