# 荣耀商城

存在 1 规则组 - [com.hihonor.vmall](/src/apps/com.hihonor.vmall.ts)

## 全屏广告-应用内广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13060881)
