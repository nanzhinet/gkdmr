# 班级小管家

存在 1 规则组 - [com.banjixiaoguanjia.app](/src/apps/com.banjixiaoguanjia.app.ts)

## 应用内广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/12904612)
- [快照-1](https://i.gkd.li/import/12906196)
