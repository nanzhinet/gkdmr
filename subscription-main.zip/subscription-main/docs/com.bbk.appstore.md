# vivo应用商店

存在 1 规则组 - [com.bbk.appstore](/src/apps/com.bbk.appstore.ts)

## 通知提示

默认禁用

- [快照-0](https://i.gkd.li/import/13198101)
- [快照-1](https://i.gkd.li/import/13198234)
- [快照-2](https://i.gkd.li/import/13246971)
- [快照-3](https://i.gkd.li/import/13884356)
