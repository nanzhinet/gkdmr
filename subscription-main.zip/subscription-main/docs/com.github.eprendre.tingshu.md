# 我的听书

存在 2 规则组 - [com.github.eprendre.tingshu](/src/apps/com.github.eprendre.tingshu.ts)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/12783466)
- [快照-1](https://i.gkd.li/import/13334850)
- [快照-2](https://i.gkd.li/import/13446735)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13625303)
