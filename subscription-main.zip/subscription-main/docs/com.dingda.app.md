# 叮嗒出行

存在 1 规则组 - [com.dingda.app](/src/apps/com.dingda.app.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13290327)
- [快照-1](https://i.gkd.li/import/13403575)
