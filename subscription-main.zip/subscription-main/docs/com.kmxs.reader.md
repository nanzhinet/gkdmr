# 七猫免费小说

存在 10 规则组 - [com.kmxs.reader](/src/apps/com.kmxs.reader.ts)

## 青少年模式弹窗

默认禁用

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12641338)

## 阅读页面底部广告

默认禁用

- [快照-0](https://i.gkd.li/import/12640296)

## 阅读结束后显示的广告

默认禁用

- [快照-0](https://i.gkd.li/import/12640303)
- [快照-1](https://i.gkd.li/import/13362269)
- [快照-2](https://i.gkd.li/import/13362272)

## 签到弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12640320)

## 右侧悬浮红包

默认禁用

- [快照-0](https://i.gkd.li/import/12640287)

## 书架顶部广告

默认禁用

- [快照-0](https://i.gkd.li/import/13489942)

## 【字节】视频广告

默认禁用 - 此规则有概率误触或失效，请谨慎选择开启。

- [快照-0](https://i.gkd.li/import/13459157)
- [快照-1](https://i.gkd.li/import/13459172)
- [快照-2](https://i.gkd.li/import/13459174)
- [快照-3](https://i.gkd.li/import/13459182)

## 【百度】全屏广告

默认禁用 - 此规则有概率误触或失效，请谨慎选择开启。

- [快照-0](https://i.gkd.li/import/13472957)

## 【腾讯】全屏广告

默认禁用 - 此规则有概率误触或失效，请谨慎选择开启。

- [快照-0](https://i.gkd.li/import/13472955)
