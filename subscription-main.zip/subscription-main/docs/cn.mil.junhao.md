# 中国军号

存在 3 规则组 - [cn.mil.junhao](/src/apps/cn.mil.junhao.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13806892)

## 功能类-首页右侧浮窗

默认禁用

- [快照-0](https://i.gkd.li/import/13806894)

## 功能类-意见反馈浮窗

默认禁用

- [快照-0](https://i.gkd.li/import/13806896)
