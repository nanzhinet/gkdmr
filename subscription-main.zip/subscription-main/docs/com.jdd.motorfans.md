# 摩托范

存在 3 规则组 - [com.jdd.motorfans](/src/apps/com.jdd.motorfans.ts)

## 弹窗广告

默认禁用

- [示例-0](https://user-images.githubusercontent.com/44717382/270852019-b0296eaa-a378-49b3-877b-acefca2a7d58.gif)

- [快照-0](https://i.gkd.li/import/12733646)
- [快照-1](https://i.gkd.li/import/12798654)
- [快照-2](https://i.gkd.li/import/12878843)
- [快照-3](https://i.gkd.li/import/12913956)
- [快照-4](https://i.gkd.li/import/13188861)
- [快照-5](https://i.gkd.li/import/12840710)
- [快照-6](https://i.gkd.li/import/13188928)
- [快照-7](https://i.gkd.li/import/12826288)

## 信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/12826382)
- [快照-1](https://i.gkd.li/import/12829069)

## 文章内容弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12888087)
