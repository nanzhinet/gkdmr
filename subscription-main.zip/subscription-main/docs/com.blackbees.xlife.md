# Xlife

存在 1 规则组 - [com.blackbees.xlife](/src/apps/com.blackbees.xlife.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13359460)
