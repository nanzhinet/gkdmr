# 彩虹多多

存在 2 规则组 - [com.ddyc.lotterytool](/src/apps/com.ddyc.lotterytool.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13324555)

## 请求推送通知弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13325888)
