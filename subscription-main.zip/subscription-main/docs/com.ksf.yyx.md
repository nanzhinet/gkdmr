# OMOFUN

存在 3 规则组 - [com.ksf.yyx](/src/apps/com.ksf.yyx.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12775918)
- [快照-1](https://i.gkd.li/import/12775919)
- [快照-2](https://i.gkd.li/import/12775926)

## 首页通知

默认禁用

- [快照-0](https://i.gkd.li/import/12775920)

## 插屏广告

默认禁用

- [快照-0](https://i.gkd.li/import/12775922)
- [快照-1](https://i.gkd.li/import/12775923)
- [快照-2](https://i.gkd.li/import/12998899)
- [快照-3](https://i.gkd.li/import/12775925)
- [快照-4](https://i.gkd.li/import/12775924)
- [快照-5](https://i.gkd.li/import/12775921)
- [快照-6](https://i.gkd.li/import/12776903)
- [快照-7](https://i.gkd.li/import/12789196)
- [快照-8](https://i.gkd.li/import/12789928)
