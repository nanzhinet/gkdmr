# LOFTER

存在 1 规则组 - [com.lofter.android](/src/apps/com.lofter.android.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13189846)
- [快照-1](https://i.gkd.li/import/13189906)
- [快照-2](https://i.gkd.li/import/13635533)
