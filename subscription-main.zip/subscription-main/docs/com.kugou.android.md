# 酷狗音乐

存在 3 规则组 - [com.kugou.android](/src/apps/com.kugou.android.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12775410)
- [快照-1](https://i.gkd.li/import/13426030)
- [快照-2](https://i.gkd.li/import/13468987)

## 个人页顶部广告

默认禁用

- [示例-0](https://m.gkd.li/87047583/9e150986-2103-4130-a12f-12ed2b07ef90)

- [快照-0](https://i.gkd.li/import/13558426)

## VIP弹窗

默认禁用

- [示例-0](https://m.gkd.li/87047583/84c1379f-5eb1-4982-b27b-35e267594101)

- [快照-0](https://i.gkd.li/import/13548005)
