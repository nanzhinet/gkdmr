# 用药参考

存在 2 规则组 - [com.ky.medical.reference](/src/apps/com.ky.medical.reference.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12918049)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12840924)
