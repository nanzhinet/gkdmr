# vivo 软件包安装程序

存在 1 规则组 - [com.android.packageinstaller](/src/apps/com.android.packageinstaller.ts)

## 自动安装应用

默认禁用

- [快照-0](https://i.gkd.li/import/13206444)
- [快照-1](https://i.gkd.li/import/13206476)
- [快照-2](https://i.gkd.li/import/13766420)
