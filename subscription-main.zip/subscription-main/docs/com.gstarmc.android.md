# CAD看图王

存在 1 规则组 - [com.gstarmc.android](/src/apps/com.gstarmc.android.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13761120)
- [快照-1](https://i.gkd.li/import/12855855)
