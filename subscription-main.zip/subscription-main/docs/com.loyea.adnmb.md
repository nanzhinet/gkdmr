# 蓝岛

存在 1 规则组 - [com.loyea.adnmb](/src/apps/com.loyea.adnmb.ts)

## 通知弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13623450)
