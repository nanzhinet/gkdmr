# 长投学堂

存在 1 规则组 - [com.ichangtou](/src/apps/com.ichangtou.ts)

## 开屏广告

- [示例-0](https://m.gkd.li/47232102/07e0dd37-6460-4dc9-ad33-18e69ba6f947)

- [快照-0](https://i.gkd.li/import/13515731)
