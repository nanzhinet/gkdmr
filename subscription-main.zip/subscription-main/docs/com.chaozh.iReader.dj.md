# 得间免费小说

存在 1 规则组 - [com.chaozh.iReader.dj](/src/apps/com.chaozh.iReader.dj.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13175317)
- [快照-1](https://i.gkd.li/import/13190313)
