# 天府通

存在 1 规则组 - [com.chinarainbow.tft](/src/apps/com.chinarainbow.tft.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13269854)
- [快照-1](https://i.gkd.li/import/13468554)
