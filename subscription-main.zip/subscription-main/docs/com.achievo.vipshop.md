# 唯品会

存在 1 规则组 - [com.achievo.vipshop](/src/apps/com.achievo.vipshop.ts)

## 开屏广告
