# 百度网盘

存在 10 规则组 - [com.baidu.netdisk](/src/apps/com.baidu.netdisk.ts)

## 活动弹窗

默认禁用 - 关闭各种活动弹窗信息

- [快照-0](https://i.gkd.li/import/12642505)
- [快照-1](https://i.gkd.li/import/12923937)

## 首页banner广告

默认禁用

- [快照-0](https://i.gkd.li/import/12706544)

## 首页热门广告

默认禁用

- [快照-0](https://i.gkd.li/import/12706544)

## 我的页面-限时福利

默认禁用

- [快照-0](https://i.gkd.li/import/12706549)

## 相册页面-激活无限空间弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12648987)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12863984)

## 续费横幅提示

默认禁用 - 关闭续费横幅提示

- [快照-0](https://i.gkd.li/import/12924036)

## 开启消息通知弹窗

默认禁用 - 自动点击关闭

- [快照-0](https://i.gkd.li/import/12923936)

## 看视频免费享极速下载弹窗

默认禁用 - 自动点击x按钮

- [快照-0](https://i.gkd.li/import/12783106)

## 幸运券包弹窗

默认禁用 - 自动点击关闭

- [快照-0](https://i.gkd.li/import/13806852)
