# 人人视频

存在 2 规则组 - [com.example.pptv](/src/apps/com.example.pptv.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13669401)
- [快照-1](https://i.gkd.li/import/13761160)

## 青少年模式

默认禁用

- [快照-0](https://i.gkd.li/import/13761159)
