# 智慧搜索

存在 1 规则组 - [com.huawei.search](/src/apps/com.huawei.search.ts)

## 下拉搜索横幅广告

默认禁用

- [快照-0](https://i.gkd.li/import/12667938)
- [快照-1](https://i.gkd.li/import/12745008)
- [快照-2](https://i.gkd.li/import/12841076)
- [快照-3](https://i.gkd.li/import/13266095)
- [快照-4](https://i.gkd.li/import/12745001)
