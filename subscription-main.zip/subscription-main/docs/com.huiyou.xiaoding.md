# 校钉

存在 1 规则组 - [com.huiyou.xiaoding](/src/apps/com.huiyou.xiaoding.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12699825)
- [快照-1](https://i.gkd.li/import/12699822)
- [快照-2](https://i.gkd.li/import/12699790)
