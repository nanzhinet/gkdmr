# 四川航空

存在 1 规则组 - [com.bw30.zsch](/src/apps/com.bw30.zsch.ts)

## 升级弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13068699)
