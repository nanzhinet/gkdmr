# 京喜特价

存在 2 规则组 - [com.jd.jdlite](/src/apps/com.jd.jdlite.ts)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12727396)

## 请求通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13062969)
