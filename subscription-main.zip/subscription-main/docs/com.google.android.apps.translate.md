# Google翻译

存在 1 规则组 - [com.google.android.apps.translate](/src/apps/com.google.android.apps.translate.ts)

## 登录弹窗

默认禁用 - 登录备份翻译记录

- [快照-0](https://i.gkd.li/import/13495796)
