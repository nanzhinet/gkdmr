# 搜索

存在 1 规则组 - [com.android.quicksearchbox](/src/apps/com.android.quicksearchbox.ts)

## 局部广告-广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/13897834)
