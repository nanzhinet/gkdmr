# 倍思

存在 1 规则组 - [com.baseus.intelligent](/src/apps/com.baseus.intelligent.ts)

## 定位提示-定位请求

默认禁用 - 点击取消-点击取消

- [快照-0](https://i.gkd.li/import/13827653)
- [快照-1](https://i.gkd.li/import/13827986)
