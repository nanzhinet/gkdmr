# 学习通

存在 1 规则组 - [com.chaoxing.mobile](/src/apps/com.chaoxing.mobile.ts)

## 开启消息通知

默认禁用 - 自动点击关闭

- [快照-0](https://i.gkd.li/import/13197374)
