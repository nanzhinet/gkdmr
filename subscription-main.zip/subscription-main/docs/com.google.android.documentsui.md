# Android 系统文件选择器

存在 1 规则组 - [com.google.android.documentsui](/src/apps/com.google.android.documentsui.ts)

## 授权第三方应用访问文件夹

默认禁用 - 自动点击【使用此文件夹】->【允许】

- [快照-0](https://i.gkd.li/import/12799610)
- [快照-1](https://i.gkd.li/import/12799603)
