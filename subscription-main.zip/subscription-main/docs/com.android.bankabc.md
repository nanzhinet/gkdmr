# 中国农业银行

存在 3 规则组 - [com.android.bankabc](/src/apps/com.android.bankabc.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12472629)
- [快照-1](https://i.gkd.li/import/13196201)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12685502)

## 切换乡村版弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12685764)
