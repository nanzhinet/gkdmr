# 华图在线

存在 2 规则组 - [com.huatu.handheld_huatu](/src/apps/com.huatu.handheld_huatu.ts)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12715702)
- [快照-1](https://i.gkd.li/import/12744973)

## 请求通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12715719)
