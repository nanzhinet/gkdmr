# i 音乐

存在 1 规则组 - [com.android.bbkmusic](/src/apps/com.android.bbkmusic.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13400275)
