# 99手游加速器

存在 2 规则组 - [com.excean.na](/src/apps/com.excean.na.ts)

## 局部广告-卡片广告

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13931051)

## 全屏广告-首页弹窗广告

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13930990)
