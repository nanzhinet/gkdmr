# 相册

存在 2 规则组 - [com.coloros.gallery3d](/src/apps/com.coloros.gallery3d.ts)

## 更新提示

默认禁用

- [示例-0](https://m.gkd.li/47232102/0dae9f4b-8432-4cf4-b648-07ae17cdece2)

- [快照-0](https://i.gkd.li/import/13554797)

## 开启相册同步弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13637185)
