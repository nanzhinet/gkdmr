# 人民日报

存在 1 规则组 - [com.facetech.konking](/src/apps/com.facetech.konking.ts)

## 应用内广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12841081)
