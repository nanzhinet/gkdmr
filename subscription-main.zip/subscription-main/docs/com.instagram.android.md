# Instagram

存在 1 规则组 - [com.instagram.android](/src/apps/com.instagram.android.ts)

## 信息流广告

默认禁用 - 但是步骤较多, 影响app使用

- [快照-0](https://i.gkd.li/import/12798562)
- [快照-1](https://i.gkd.li/import/12798571)
- [快照-2](https://i.gkd.li/import/12829448)
- [快照-3](https://i.gkd.li/import/12798590)
- [快照-4](https://i.gkd.li/import/12829464)
- [快照-5](https://i.gkd.li/import/12829492)
