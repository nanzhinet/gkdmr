# 店长直聘

存在 1 规则组 - [com.hpbr.directhires](/src/apps/com.hpbr.directhires.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13774242)
