# 魔音MORIN

存在 2 规则组 - [com.feiyu.morin](/src/apps/com.feiyu.morin.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13521556)
- [快照-1](https://i.gkd.li/import/13546184)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/13521680)
- [快照-1](https://i.gkd.li/import/13625476)
