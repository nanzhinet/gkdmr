# 爱企查

存在 3 规则组 - [com.baidu.xin.aiqicha](/src/apps/com.baidu.xin.aiqicha.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12755738)
- [快照-1](https://i.gkd.li/import/12755762)

## 请求通知权限弹窗

默认禁用 - 自动点击【不允许】

- [快照-0](https://i.gkd.li/import/12755733)

## 请求通知权限提示信息

默认禁用 - 自动点击x按钮

- [快照-0](https://i.gkd.li/import/12755756)
