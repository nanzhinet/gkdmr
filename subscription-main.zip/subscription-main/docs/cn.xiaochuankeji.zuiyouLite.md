# 皮皮搞笑

存在 2 规则组 - [cn.xiaochuankeji.zuiyouLite](/src/apps/cn.xiaochuankeji.zuiyouLite.ts)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12745083)
- [快照-1](https://i.gkd.li/import/13446652)

## 信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/13387116)
- [快照-1](https://i.gkd.li/import/13387155)
