# 万能小组件 Top Widgets

存在 1 规则组 - [com.growing.topwidgets](/src/apps/com.growing.topwidgets.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13334835)
- [快照-1](https://i.gkd.li/import/13363115)
