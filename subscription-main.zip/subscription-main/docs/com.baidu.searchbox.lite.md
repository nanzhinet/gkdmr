# 百度极速版

存在 1 规则组 - [com.baidu.searchbox.lite](/src/apps/com.baidu.searchbox.lite.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13741508)
