# 爱康约体检查报告

存在 1 规则组 - [com.ikang.official](/src/apps/com.ikang.official.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13197061)
