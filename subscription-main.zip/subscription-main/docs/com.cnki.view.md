# 知网文化

存在 1 规则组 - [com.cnki.view](/src/apps/com.cnki.view.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12755689)
- [快照-1](https://i.gkd.li/import/12755700)
