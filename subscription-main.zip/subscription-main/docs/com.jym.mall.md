# 交易猫

存在 1 规则组 - [com.jym.mall](/src/apps/com.jym.mall.ts)

## 升级弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12496974)
