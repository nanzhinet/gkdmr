# MT管理器

存在 1 规则组 - [bin.mt.plus](/src/apps/bin.mt.plus.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12908784)
