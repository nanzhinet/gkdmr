# GIF助手

存在 1 规则组 - [com.didikee.gifparser](/src/apps/com.didikee.gifparser.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12674390)
