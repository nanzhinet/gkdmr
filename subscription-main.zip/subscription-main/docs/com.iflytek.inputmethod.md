# 讯飞输入法

存在 1 规则组 - [com.iflytek.inputmethod](/src/apps/com.iflytek.inputmethod.ts)

## 开屏广告

点击右上方跳过按钮

- [快照-0](https://i.gkd.li/import/12906597)
- [快照-1](https://i.gkd.li/import/13054922)
- [快照-2](https://i.gkd.li/import/13635665)
