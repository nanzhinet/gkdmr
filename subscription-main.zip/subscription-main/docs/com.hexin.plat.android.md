# 同花顺

存在 2 规则组 - [com.hexin.plat.android](/src/apps/com.hexin.plat.android.ts)

## 信息流广告

默认禁用 - 信息流广告-点击x按钮-点击内容质量差

- [快照-0](https://i.gkd.li/import/12662754)
- [快照-1](https://i.gkd.li/import/12662781)

## 指数页面-底部产品广告

默认禁用

- [快照-0](https://i.gkd.li/import/12662656)
