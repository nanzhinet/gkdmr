# 万能遥控

存在 2 规则组 - [com.duokan.phone.remotecontroller](/src/apps/com.duokan.phone.remotecontroller.ts)

## 底部横幅广告

默认禁用

## 申请定位

默认禁用

- [快照-0](https://i.gkd.li/import/13642080)
