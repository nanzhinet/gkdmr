# TeraBox

存在 3 规则组 - [com.dubox.drive](/src/apps/com.dubox.drive.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13200574)
- [快照-1](https://i.gkd.li/import/13688384)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13200577)

## 通知权限

默认禁用

- [快照-0](https://i.gkd.li/import/13688406)
