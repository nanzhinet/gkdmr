# 丰巢管家

存在 1 规则组 - [com.fcbox.hivebox](/src/apps/com.fcbox.hivebox.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13459000)
