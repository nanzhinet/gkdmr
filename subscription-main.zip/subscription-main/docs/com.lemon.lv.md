# 剪映

存在 1 规则组 - [com.lemon.lv](/src/apps/com.lemon.lv.ts)

## 导出界面底部广告

默认禁用 - 关闭完成导出后的下方广告

- [快照-0](https://i.gkd.li/import/12911010)
