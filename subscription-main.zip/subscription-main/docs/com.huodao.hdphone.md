# 找靓机

存在 1 规则组 - [com.huodao.hdphone](/src/apps/com.huodao.hdphone.ts)

## 全屏广告-超级补贴日弹窗

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13927567)
