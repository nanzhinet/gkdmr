# OurPlay加速器

存在 1 规则组 - [com.excean.splay](/src/apps/com.excean.splay.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12684551)
