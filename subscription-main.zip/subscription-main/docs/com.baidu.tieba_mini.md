# 贴吧极速版

存在 1 规则组 - [com.baidu.tieba_mini](/src/apps/com.baidu.tieba_mini.ts)

## 首页-信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/12905039)
- [快照-1](https://i.gkd.li/import/12904633)
