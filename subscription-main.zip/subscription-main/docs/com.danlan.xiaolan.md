# Blued极速版

存在 2 规则组 - [com.danlan.xiaolan](/src/apps/com.danlan.xiaolan.ts)

## 附近的人-广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/13421613)
- [快照-1](https://i.gkd.li/import/13421622)

## 来访-广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/13421923)
- [快照-1](https://i.gkd.li/import/13422170)
