# 智慧生活

存在 1 规则组 - [com.huawei.smarthome](/src/apps/com.huawei.smarthome.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12738253)
