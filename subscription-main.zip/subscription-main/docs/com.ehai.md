# 一嗨租车

存在 1 规则组 - [com.ehai](/src/apps/com.ehai.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13483557)
