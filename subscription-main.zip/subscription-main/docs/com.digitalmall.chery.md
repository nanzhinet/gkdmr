# 奇瑞汽车

存在 1 规则组 - [com.digitalmall.chery](/src/apps/com.digitalmall.chery.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13392254)
