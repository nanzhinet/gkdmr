# WPS

存在 6 规则组 - [cn.wps.moffice_eng](/src/apps/cn.wps.moffice_eng.ts)

## 首页-文档列表广告

默认禁用

- [示例-0](https://github.com/gkd-kit/subscription/assets/38517192/57787554-0443-4bc0-9f29-1759aae07b9b)

- [快照-0](https://i.gkd.li/import/12505350)
- [快照-1](https://i.gkd.li/import/12505286)
- [快照-2](https://i.gkd.li/import/12505365)
- [快照-3](https://i.gkd.li/import/13259090)

## 首页-弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13259097)
- [快照-1](https://i.gkd.li/import/12882712)

## 升级提示

默认禁用

- [快照-0](https://i.gkd.li/import/12882371)

## 开启WPS云服务

默认禁用 - 自动点击不开启

- [快照-0](https://i.gkd.li/import/12882536)
- [快照-1](https://i.gkd.li/import/12882610)
- [快照-2](https://i.gkd.li/import/12882678)
- [快照-3](https://i.gkd.li/import/12882554)

## 文档末尾广告

默认禁用

- [快照-0](https://i.gkd.li/import/13513911)
- [快照-1](https://i.gkd.li/import/13513914)

## 首页-底部广告

默认禁用

- [快照-0](https://i.gkd.li/import/13804525)
