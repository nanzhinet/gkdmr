# 百度网盘-三星版本

存在 4 规则组 - [com.baidu.netdisk.samsung](/src/apps/com.baidu.netdisk.samsung.ts)

## 弹窗广告

默认禁用 - 点击右上角x图标按钮

- [快照-0](https://i.gkd.li/import/12738331)

## 关闭购买套餐卡片广告

默认禁用

- [快照-0](https://i.gkd.li/import/12738388)

## 关闭[专属福利]卡片广告

默认禁用

- [快照-0](https://i.gkd.li/import/12738404)

## 关闭[今日福利]卡片广告

默认禁用 - 会员-我的会员-底部卡片广告,点击[去使用]右侧的x关闭图标

- [快照-0](https://i.gkd.li/import/12738449)
