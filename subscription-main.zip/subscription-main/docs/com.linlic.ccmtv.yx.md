# CCMTV临床频道

存在 1 规则组 - [com.linlic.ccmtv.yx](/src/apps/com.linlic.ccmtv.yx.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13625401)
