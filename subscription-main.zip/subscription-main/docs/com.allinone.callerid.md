# Showcaller

存在 1 规则组 - [com.allinone.callerid](/src/apps/com.allinone.callerid.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13696207)
- [快照-1](https://i.gkd.li/import/13696205)
