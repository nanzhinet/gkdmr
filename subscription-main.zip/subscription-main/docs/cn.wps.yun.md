# 金山文档

存在 1 规则组 - [cn.wps.yun](/src/apps/cn.wps.yun.ts)

## 列表广告

默认禁用 - 点击右侧x

- [示例-0](https://m.gkd.li/47232102/bc97cb52-aad0-4114-a548-5831edbe342d)

- [快照-0](https://i.gkd.li/import/13495062)
