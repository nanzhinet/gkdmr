# 懂球帝

存在 6 规则组 - [com.dongqiudi.news](/src/apps/com.dongqiudi.news.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12620568)
- [快照-1](https://i.gkd.li/import/12620577)
- [快照-2](https://i.gkd.li/import/12621997)
- [快照-3](https://i.gkd.li/import/12620583)
- [快照-4](https://i.gkd.li/import/12621953)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12621980)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12620586)

## 首页信息流广告

默认禁用 - 点击广告卡片x关闭按钮-关闭反馈理由弹窗

- [快照-0](https://i.gkd.li/import/12620656)
- [快照-1](https://i.gkd.li/import/12620654)
- [快照-2](https://i.gkd.li/import/12620788)

## 首页-广告弹窗

默认禁用 - 点击底部【x】关闭

- [快照-0](https://i.gkd.li/import/13260467)

## 数据页弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13626900)
- [快照-1](https://i.gkd.li/import/13627105)
- [快照-2](https://i.gkd.li/import/13627106)
- [快照-3](https://i.gkd.li/import/12620588)
