# 天天跳绳

存在 2 规则组 - [com.gkid.crazyrope](/src/apps/com.gkid.crazyrope.ts)

## 会员提示

默认禁用 - 点击不需要

- [快照-0](https://i.gkd.li/import/12916419)

## 浮窗广告

默认禁用 - 二步确认

- [快照-0](https://i.gkd.li/import/13262845)
- [快照-1](https://i.gkd.li/import/13262844)
