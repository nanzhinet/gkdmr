# 百词斩

存在 2 规则组 - [com.jiongji.andriod.card](/src/apps/com.jiongji.andriod.card.ts)

## 活动弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13415075)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13488652)
