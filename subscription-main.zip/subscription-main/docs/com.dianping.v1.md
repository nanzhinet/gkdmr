# 大众点评

存在 5 规则组 - [com.dianping.v1](/src/apps/com.dianping.v1.ts)

## 主页推荐关注弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12727011)

## 消息页上方开启系统通知提醒

默认禁用

- [快照-0](https://i.gkd.li/import/12727070)

## 关闭[签到开红包]

默认禁用 - 点击右下角悬浮图片右上角的x图标

- [快照-0](https://i.gkd.li/import/12727366)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13538340)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/13759369)
