# 嘀嗒出行

存在 1 规则组 - [com.didapinche.booking](/src/apps/com.didapinche.booking.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13988957)
- [快照-1](https://i.gkd.li/import/13989178)
