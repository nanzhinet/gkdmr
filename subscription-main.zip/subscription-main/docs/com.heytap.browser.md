# OPPO浏览器

存在 1 规则组 - [com.heytap.browser](/src/apps/com.heytap.browser.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12841168)
- [快照-1](https://i.gkd.li/import/13199536)
