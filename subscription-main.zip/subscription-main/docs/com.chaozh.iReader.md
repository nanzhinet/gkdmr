# VIVO 电子书

存在 2 规则组 - [com.chaozh.iReader](/src/apps/com.chaozh.iReader.ts)

## 权限提示

默认禁用

- [快照-0](https://i.gkd.li/import/13627649)

## 通知提示

默认禁用

- [快照-0](https://i.gkd.li/import/13837961)
