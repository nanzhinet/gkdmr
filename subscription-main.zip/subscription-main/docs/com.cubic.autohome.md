# 汽车之家

存在 2 规则组 - [com.cubic.autohome](/src/apps/com.cubic.autohome.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12836324)

## 局部广告-右下角领福利悬浮窗

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13885414)
