# 南网在线

存在 2 规则组 - [com.csg.palmhall](/src/apps/com.csg.palmhall.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12700060)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12700075)
