# 翼支付

存在 4 规则组 - [com.chinatelecom.bestpayclient](/src/apps/com.chinatelecom.bestpayclient.ts)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13391544)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13402692)
- [快照-1](https://i.gkd.li/import/13455790)
- [快照-2](https://i.gkd.li/import/13626324)
- [快照-3](https://i.gkd.li/import/13455929)
- [快照-4](https://i.gkd.li/import/13696322)
- [快照-5](https://i.gkd.li/import/13696323)

## 悬浮窗小广告

默认禁用

- [快照-0](https://i.gkd.li/import/13402711)

## 年底积分活动弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13543032)
- [快照-1](https://i.gkd.li/import/13625037)
