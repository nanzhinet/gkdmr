# iGPSPORT

存在 1 规则组 - [com.igpsport.igpsportandroid](/src/apps/com.igpsport.igpsportandroid.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13797203)
