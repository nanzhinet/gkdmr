# 咕咚

存在 1 规则组 - [com.codoon.gps](/src/apps/com.codoon.gps.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13358586)
- [快照-1](https://i.gkd.li/import/13348663)
