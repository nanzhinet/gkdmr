# 全能计算器

存在 1 规则组 - [com.jincheng.supercaculator](/src/apps/com.jincheng.supercaculator.ts)

## 弹窗广告

默认禁用 - 点击右上角x

- [快照-0](https://i.gkd.li/import/12859523)
- [快照-1](https://i.gkd.li/import/12859545)
- [快照-2](https://i.gkd.li/import/13670598)
- [快照-3](https://i.gkd.li/import/13261870)
- [快照-4](https://i.gkd.li/import/13378847)
