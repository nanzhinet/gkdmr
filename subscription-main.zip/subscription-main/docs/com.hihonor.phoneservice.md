# 我的荣耀

存在 1 规则组 - [com.hihonor.phoneservice](/src/apps/com.hihonor.phoneservice.ts)

## 请求位置权限提示信息

默认禁用

- [快照-0](https://i.gkd.li/import/12783134)
