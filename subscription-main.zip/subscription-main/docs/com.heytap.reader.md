# 阅读

存在 3 规则组 - [com.heytap.reader](/src/apps/com.heytap.reader.ts)

## 首页广告

默认禁用

- [示例-0](https://m.gkd.li/6328439/4feb19d4-f90f-4ed5-b025-9c2a6e4fc479)

- [快照-0](https://i.gkd.li/import/13387130)

## 首页浮窗

默认禁用

- [示例-0](https://m.gkd.li/6328439/860371ea-1f09-4f82-8ed6-1436eca4a50d)

- [快照-0](https://i.gkd.li/import/13387138)

## 今日推荐

默认禁用

- [示例-0](https://m.gkd.li/6328439/3ee7210c-970e-4c9a-acb6-9254245c27a0)

- [快照-0](https://i.gkd.li/import/13387159)
