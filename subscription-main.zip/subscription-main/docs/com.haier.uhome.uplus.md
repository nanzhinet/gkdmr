# 海尔智家

存在 2 规则组 - [com.haier.uhome.uplus](/src/apps/com.haier.uhome.uplus.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12726844)
- [快照-1](https://i.gkd.li/import/12726801)

## 请求通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12726829)
