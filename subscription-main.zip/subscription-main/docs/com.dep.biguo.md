# 自考笔果题库

存在 3 规则组 - [com.dep.biguo](/src/apps/com.dep.biguo.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12708751)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12708756)

## 请求定位权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12708770)
