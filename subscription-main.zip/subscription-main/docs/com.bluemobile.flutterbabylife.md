# 宝宝生活记录

存在 1 规则组 - [com.bluemobile.flutterbabylife](/src/apps/com.bluemobile.flutterbabylife.ts)

## 应用内广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13632639)
