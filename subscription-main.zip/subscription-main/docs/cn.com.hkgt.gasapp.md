# 易捷加油

存在 1 规则组 - [cn.com.hkgt.gasapp](/src/apps/cn.com.hkgt.gasapp.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12744270)
