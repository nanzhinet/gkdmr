# fiil+

存在 1 规则组 - [com.fengeek.f002](/src/apps/com.fengeek.f002.ts)

## 自动连接耳机

默认禁用 - 点击连接耳机按钮,点击扫描到的第一个设备

- [快照-0](https://i.gkd.li/import/13161277)
- [快照-1](https://i.gkd.li/import/13161365)
