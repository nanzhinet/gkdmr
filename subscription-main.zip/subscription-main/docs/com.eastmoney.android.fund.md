# 天天基金

存在 3 规则组 - [com.eastmoney.android.fund](/src/apps/com.eastmoney.android.fund.ts)

## 自选页面广告

默认禁用

- [快照-0](https://i.gkd.li/import/12642387)

## 自选页面缩写提示信息

默认禁用

- [快照-0](https://i.gkd.li/import/12642387)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13546927)
