# 最右

存在 5 规则组 - [cn.xiaochuankeji.tieba](/src/apps/cn.xiaochuankeji.tieba.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12660882)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12660929)

## 评论区广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/12661011)
- [快照-1](https://i.gkd.li/import/12661028)

## 系统通知弹窗

默认禁用 - 系统通知弹窗，点击暂不开启

- [快照-0](https://i.gkd.li/import/12660823)

## 系统通知提示信息

默认禁用 - 系统通知提示信息，点击x按钮

- [快照-0](https://i.gkd.li/import/12660851)
