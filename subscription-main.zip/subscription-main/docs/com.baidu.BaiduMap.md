# 百度地图

存在 9 规则组 - [com.baidu.BaiduMap](/src/apps/com.baidu.BaiduMap.ts)

## 地图上方黄页横幅

默认禁用

- [快照-0](https://i.gkd.li/import/12642301)
- [快照-1](https://i.gkd.li/import/12801465)
- [快照-2](https://i.gkd.li/import/12909281)

## 打车界面-右侧悬浮球

默认禁用

- [快照-0](https://i.gkd.li/import/12642307)

## 美食大礼包弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12642310)

## 酒店提前订弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12642319)

## 请求定位弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12660884)
- [快照-1](https://i.gkd.li/import/12660883)
- [快照-2](https://i.gkd.li/import/12909299)

## 打车界面-弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12909300)
- [快照-1](https://i.gkd.li/import/12930699)

## 升级更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12909385)

## 打开通知权限

默认禁用

- [快照-0](https://i.gkd.li/import/13258995)

## 通勤卡-添加至桌面

默认禁用 - 点击取消

- [快照-0](https://i.gkd.li/import/13439258)
