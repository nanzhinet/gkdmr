# 古文岛

存在 2 规则组 - [com.guwendao.gwd](/src/apps/com.guwendao.gwd.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12776605)

## 第三方 SDK 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12776607)
- [快照-1](https://i.gkd.li/import/12777151)
- [快照-2](https://i.gkd.li/import/12781344)
- [快照-3](https://i.gkd.li/import/12924728)
- [快照-4](https://i.gkd.li/import/12781327)
