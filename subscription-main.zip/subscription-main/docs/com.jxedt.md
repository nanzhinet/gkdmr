# 驾校一点通

存在 2 规则组 - [com.jxedt](/src/apps/com.jxedt.ts)

## 广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/13195641)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13476741)
