# 中国移动云盘

存在 4 规则组 - [com.chinamobile.mcloud](/src/apps/com.chinamobile.mcloud.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12774833)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13627826)
- [快照-1](https://i.gkd.li/import/13627832)

## 悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/13627834)

## 请求开启自动备份弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13627830)
