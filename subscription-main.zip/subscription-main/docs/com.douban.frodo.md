# 豆瓣

存在 9 规则组 - [com.douban.frodo](/src/apps/com.douban.frodo.ts)

## 不分享/同步作品短评

默认禁用 - 书影音-作品-状态-不分享/同步短评(5s后可手动)

- [快照-0](https://i.gkd.li/import/12508777)
- [快照-1](https://i.gkd.li/import/12508777)

## 剧照广告

默认禁用

- [快照-0](https://i.gkd.li/import/12509475)
- [快照-1](https://i.gkd.li/import/12509476)

## 信息流广告

默认禁用 - 首页动态/推荐,小组讨论列表,帖子底部,点击广告关闭后出现关闭原因底部菜单-点击不感兴趣

- [快照-0](https://i.gkd.li/import/12547964)
- [快照-1](https://i.gkd.li/import/12548011)
- [快照-2](https://i.gkd.li/import/12548046)
- [快照-3](https://i.gkd.li/import/12723569)
- [快照-4](https://i.gkd.li/import/13347455)
- [快照-5](https://i.gkd.li/import/12548016)
- [快照-6](https://i.gkd.li/import/12723422)

## 卡片广告

默认禁用 - 书影音-卡片广告-点击卡片右下角"广告"文字

- [快照-0](https://i.gkd.li/import/12548160)
- [快照-1](https://i.gkd.li/import/12548131)
- [快照-2](https://i.gkd.li/import/12548116)

## 关闭评分反馈弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12548314)

## 搜索页/帖子内容与评论区中间的卡片式广告

默认禁用 - 部分有二次弹窗

- [快照-0](https://i.gkd.li/import/12674798)
- [快照-1](https://i.gkd.li/import/12674842)
- [快照-2](https://i.gkd.li/import/12723462)
- [快照-3](https://i.gkd.li/import/12723800)
- [快照-4](https://i.gkd.li/import/13402399)
- [快照-5](https://i.gkd.li/import/12548476)
- [快照-6](https://i.gkd.li/import/12548064)
- [快照-7](https://i.gkd.li/import/12548450)
- [快照-8](https://i.gkd.li/import/12723751)
- [快照-9](https://i.gkd.li/import/13062693)
- [快照-10](https://i.gkd.li/import/13692895)
- [快照-11](https://i.gkd.li/import/12548016)
- [快照-12](https://i.gkd.li/import/12723422)

## 个性化内容推荐弹窗

默认禁用 - 首页底部-个性化内容推荐弹窗-点击卡片右上角x直接关闭

- [快照-0](https://i.gkd.li/import/12836798)

## 弹窗广告

默认禁用 - 浏览详情时弹窗广告,点击右上角x

- [快照-0](https://i.gkd.li/import/13195565)
- [快照-1](https://i.gkd.li/import/13296656)
- [快照-2](https://i.gkd.li/import/13328126)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13228832)
- [快照-1](https://i.gkd.li/import/13659160)
