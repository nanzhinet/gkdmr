# 小熊油耗

存在 3 规则组 - [com.firebear.androil](/src/apps/com.firebear.androil.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12712742)
- [快照-1](https://i.gkd.li/import/13088169)
- [快照-2](https://i.gkd.li/import/12855707)
- [快照-3](https://i.gkd.li/import/13927561)

## 全屏广告

默认禁用 - 来自第三方SDK【穿山甲】

- [快照-0](https://i.gkd.li/import/12754919)
- [快照-1](https://i.gkd.li/import/13324698)
- [快照-2](https://i.gkd.li/import/12864214)
- [快照-3](https://i.gkd.li/import/13175439)

## 更新提示

默认禁用

- [快照-0](https://i.gkd.li/import/12755032)
