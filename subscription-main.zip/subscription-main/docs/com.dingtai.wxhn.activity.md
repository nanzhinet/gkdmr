# 新湖南

存在 1 规则组 - [com.dingtai.wxhn.activity](/src/apps/com.dingtai.wxhn.activity.ts)

## 开屏广告

- [示例-0](https://m.gkd.li/6328439/ae26cfeb-c977-416a-8ac3-6f5cc867b3ae)

- [快照-0](https://i.gkd.li/import/13374520)
