# 芒果TV

存在 4 规则组 - [com.hunantv.imgo.activity](/src/apps/com.hunantv.imgo.activity.ts)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12832447)

## 首页推荐流-卡片广告

默认禁用

- [快照-0](https://i.gkd.li/import/12472616)
- [快照-1](https://i.gkd.li/import/12472615)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12818464)
- [快照-1](https://i.gkd.li/import/12818528)
- [快照-2](https://i.gkd.li/import/13761169)

## 右侧悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/12818430)
- [快照-1](https://i.gkd.li/import/12818481)
