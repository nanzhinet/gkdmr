# 糖心Vlog

存在 4 规则组 - [com.flutter3.ctangxin.vf0egg](/src/apps/com.flutter3.ctangxin.vf0egg.ts)

## 开屏广告

默认禁用 - 虚假按钮，实际点击无法跳过，规则暂时保留

- [快照-0](https://i.gkd.li/import/12836857)

## 全屏广告-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12836891)

## 全屏广告-公告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12836854)

## 全屏广告-延迟工具(协助key1、2)

默认禁用 - 5s开屏广告后主动触发匹配
