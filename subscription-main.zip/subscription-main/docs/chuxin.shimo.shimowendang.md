# 石墨文档

存在 1 规则组 - [chuxin.shimo.shimowendang](/src/apps/chuxin.shimo.shimowendang.ts)

## 首页顶部横幅广告

默认禁用

- [快照-0](https://i.gkd.li/import/13627960)
