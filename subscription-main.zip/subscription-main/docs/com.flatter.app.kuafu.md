# 蓝奏浏览器

存在 1 规则组 - [com.flatter.app.kuafu](/src/apps/com.flatter.app.kuafu.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13470943)
