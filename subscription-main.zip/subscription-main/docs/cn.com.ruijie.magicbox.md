# 无线魔盒

存在 1 规则组 - [cn.com.ruijie.magicbox](/src/apps/cn.com.ruijie.magicbox.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12642359)
