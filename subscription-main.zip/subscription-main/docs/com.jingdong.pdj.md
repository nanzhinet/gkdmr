# 京东到家

存在 2 规则组 - [com.jingdong.pdj](/src/apps/com.jingdong.pdj.ts)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13217796)
- [快照-1](https://i.gkd.li/import/13223282)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13217634)
