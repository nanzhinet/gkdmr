# 小猿搜题

存在 1 规则组 - [com.fenbi.android.solar](/src/apps/com.fenbi.android.solar.ts)

## 升级提示

默认禁用

- [快照-0](https://i.gkd.li/import/13246056)
