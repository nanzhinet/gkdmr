# 浦发银行

存在 1 规则组 - [cn.com.spdb.mobilebank.per](/src/apps/cn.com.spdb.mobilebank.per.ts)

## 消息中心-系统通知请求

默认禁用 - 自动点击关闭。

- [快照-0](https://i.gkd.li/import/13458535)
