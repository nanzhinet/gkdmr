# 酷安

存在 4 规则组 - [com.coolapk.market](/src/apps/com.coolapk.market.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12503773)
- [快照-1](https://i.gkd.li/import/13247610)
- [快照-2](https://i.gkd.li/import/13264779)
- [快照-3](https://i.gkd.li/import/12917990)
- [快照-4](https://i.gkd.li/import/13211392)
- [快照-5](https://i.gkd.li/import/13247733)
- [快照-6](https://i.gkd.li/import/13247782)
- [快照-7](https://i.gkd.li/import/13296816)
- [快照-8](https://i.gkd.li/import/13826359)
- [快照-9](https://i.gkd.li/import/13827095)

## 卡片广告

默认禁用 - 点击卡片右上角按钮->免广告-点击不感兴趣->选择关闭原因-点击不感兴趣

- [快照-0](https://i.gkd.li/import/12707506)
- [快照-1](https://i.gkd.li/import/12642094)
- [快照-2](https://i.gkd.li/import/12642148)
- [快照-3](https://i.gkd.li/import/12774771)
- [快照-4](https://i.gkd.li/import/13257987)
- [快照-5](https://i.gkd.li/import/12707509)
- [快照-6](https://i.gkd.li/import/12642132)
- [快照-7](https://i.gkd.li/import/12642155)
- [快照-8](https://i.gkd.li/import/12774753)
- [快照-9](https://i.gkd.li/import/12472633)
- [快照-10](https://i.gkd.li/import/12655713)
- [快照-11](https://i.gkd.li/import/12660759)
- [快照-12](https://i.gkd.li/import/12706437)
- [快照-13](https://i.gkd.li/import/13786886)

## 关闭升级弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12503762)

## 关闭推送通知

默认禁用

- [快照-0](https://i.gkd.li/import/13296465)
