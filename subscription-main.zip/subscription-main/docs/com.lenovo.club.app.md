# 联想

存在 1 规则组 - [com.lenovo.club.app](/src/apps/com.lenovo.club.app.ts)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13498778)
