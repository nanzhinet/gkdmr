# 华彩人生

存在 1 规则组 - [com.hcrs](/src/apps/com.hcrs.ts)

## 开屏广告

- [示例-0](https://m.gkd.li/47232102/23ef9096-1ba8-4a68-8105-0f73c7158239)

- [快照-0](https://i.gkd.li/import/13515798)
