# 菜鸟

存在 6 规则组 - [com.cainiao.wireless](/src/apps/com.cainiao.wireless.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12914371)
- [快照-1](https://i.gkd.li/import/13692758)
- [快照-2](https://i.gkd.li/import/13042279)

## 包裹页面-地图底部横条广告

默认禁用

- [快照-0](https://i.gkd.li/import/12914450)

## 升级提示

默认禁用

- [快照-0](https://i.gkd.li/import/13042207)

## 开启消息弹窗

默认禁用 - 自动点击关闭。

- [快照-0](https://i.gkd.li/import/13068573)

## 请求好评弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13692761)

## 全屏广告-今日手气红包

默认禁用 - 点击右上角X

- [快照-0](https://i.gkd.li/import/13842492)
