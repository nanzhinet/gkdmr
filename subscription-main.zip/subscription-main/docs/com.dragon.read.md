# 番茄免费小说

存在 8 规则组 - [com.dragon.read](/src/apps/com.dragon.read.ts)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/12908734)
- [快照-1](https://i.gkd.li/import/12716444)
- [快照-2](https://i.gkd.li/import/13062909)
- [快照-3](https://i.gkd.li/import/13520314)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12716477)

## 首页右侧悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/12716506)
- [快照-1](https://i.gkd.li/import/13318796)

## 优惠券弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12910159)
- [快照-1](https://i.gkd.li/import/12878266)

## 阅读页面\_关注作者

默认禁用

- [快照-0](https://i.gkd.li/import/13399505)

## 分段广告

默认禁用

- [快照-0](https://i.gkd.li/import/13520160)
- [快照-1](https://i.gkd.li/import/13843155)
- [快照-2](https://i.gkd.li/import/13520219)
- [快照-3](https://i.gkd.li/import/13674550)
- [快照-4](https://i.gkd.li/import/13674556)
- [快照-5](https://i.gkd.li/import/13816453)
- [快照-6](https://i.gkd.li/import/13816454)

## 请求通知权限弹窗

默认禁用 - 自动点击【取消】

- [快照-0](https://i.gkd.li/import/12716592)

## 关闭阅读-全屏广告

默认禁用 - 点击右上角【关闭】

- [快照-0](https://i.gkd.li/import/13191156)
