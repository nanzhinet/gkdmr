# 百度

存在 1 规则组 - [com.baidu.searchbox](/src/apps/com.baidu.searchbox.ts)

## 红包弹窗

默认禁用 - 点击关闭

- [快照-0](https://i.gkd.li/import/13806848)
