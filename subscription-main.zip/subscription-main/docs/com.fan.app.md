# 十六番旅行

存在 2 规则组 - [com.fan.app](/src/apps/com.fan.app.ts)

## 广告卡片

默认禁用

- [快照-0](https://i.gkd.li/import/13258021)
- [快照-1](https://i.gkd.li/import/13258015)
- [快照-2](https://i.gkd.li/import/13258018)

## 开启通知弹窗

默认禁用 - 自动点击“以后再说”

- [快照-0](https://i.gkd.li/import/13601734)
