# 安心记加班

存在 1 规则组 - [com.julanling.app](/src/apps/com.julanling.app.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13523567)
