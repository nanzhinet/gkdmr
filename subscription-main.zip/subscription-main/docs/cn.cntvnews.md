# 央视新闻

存在 1 规则组 - [cn.cntvnews](/src/apps/cn.cntvnews.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12749208)
