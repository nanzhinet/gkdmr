# 哈啰

存在 8 规则组 - [com.jingyao.easybike](/src/apps/com.jingyao.easybike.ts)

## 请求通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13228735)
- [快照-1](https://i.gkd.li/import/13402675)

## 请求定位权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13228677)

## 应用内活动、广告弹窗（大部分）

默认禁用

- [快照-0](https://i.gkd.li/import/12650028)
- [快照-1](https://i.gkd.li/import/12650090)
- [快照-2](https://i.gkd.li/import/13331231)

## 哈啰智能电动车-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12650163)

## 右侧悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/12650071)

## 骑行订单完成-广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12684673)

## 骑行卡-优惠券弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12739316)

## 功能类-新人教学弹窗

默认禁用 - 点击跳过

- [快照-0](https://i.gkd.li/import/13837543)
