# OPPO手机管家

存在 1 规则组 - [com.coloros.phonemanager](/src/apps/com.coloros.phonemanager.ts)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13194979)
