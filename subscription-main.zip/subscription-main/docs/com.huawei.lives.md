# 华为生活服务

存在 1 规则组 - [com.huawei.lives](/src/apps/com.huawei.lives.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13063001)
