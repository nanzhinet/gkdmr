# 必剪

存在 2 规则组 - [com.bilibili.studio](/src/apps/com.bilibili.studio.ts)

## 通知权限请求

默认禁用 - 会出现在创作、模板、我的页面，自动点击不开启。

- [快照-0](https://i.gkd.li/import/12867401)
- [快照-1](https://i.gkd.li/import/12908880)
- [快照-2](https://i.gkd.li/import/12908886)

## 版本更新

默认禁用 - 勾选【忽略】-点击【以后再说】

- [快照-0](https://i.gkd.li/import/13496049)
