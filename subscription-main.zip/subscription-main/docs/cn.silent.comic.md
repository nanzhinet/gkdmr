# 免漫

存在 1 规则组 - [cn.silent.comic](/src/apps/cn.silent.comic.ts)

## 开屏广告

- [示例-0](https://m.gkd.li/83610194/f7c54df0-30d8-405a-b7eb-dd06c8db11cf)
- [示例-1](https://m.gkd.li/83610194/94a8ecb5-1124-4090-a1ce-11340a4a76f2)
- [示例-2](https://m.gkd.li/83610194/94a8ecb5-1124-4090-a1ce-11340a4a76f2)

- [快照-0](https://i.gkd.li/import/13405442)
- [快照-1](https://i.gkd.li/import/13405483)
- [快照-2](https://i.gkd.li/import/13421452)
