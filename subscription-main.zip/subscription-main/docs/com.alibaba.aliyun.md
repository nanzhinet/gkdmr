# 阿里云

存在 1 规则组 - [com.alibaba.aliyun](/src/apps/com.alibaba.aliyun.ts)

## 请求开启通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13446162)
