# 动漫之家社区

存在 1 规则组 - [com.dmzjsq.manhua](/src/apps/com.dmzjsq.manhua.ts)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12885087)
- [快照-1](https://i.gkd.li/import/12893731)
