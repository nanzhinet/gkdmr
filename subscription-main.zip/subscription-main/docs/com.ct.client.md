# 中国电信

存在 5 规则组 - [com.ct.client](/src/apps/com.ct.client.ts)

## 用户引导

默认禁用

- [快照-0](https://i.gkd.li/import/12508971)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12819594)
- [快照-1](https://i.gkd.li/import/13316168)
- [快照-2](https://i.gkd.li/import/13695096)

## 浮窗广告

默认禁用 - 会出现在首页、查询办理页面

- [快照-0](https://i.gkd.li/import/12819676)
- [快照-1](https://i.gkd.li/import/12913735)
- [快照-2](https://i.gkd.li/import/13043345)

## 业务办理-弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12913804)

## 消息-开启消息通知

默认禁用 - 自动点击关闭

- [快照-0](https://i.gkd.li/import/13043522)
