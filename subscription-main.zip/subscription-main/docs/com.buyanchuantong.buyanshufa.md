# 不厌书法

存在 1 规则组 - [com.buyanchuantong.buyanshufa](/src/apps/com.buyanchuantong.buyanshufa.ts)

## 功能介绍

默认禁用

- [快照-0](https://i.gkd.li/import/13425296)
