# 交通银行

存在 2 规则组 - [com.bankcomm.Bankcomm](/src/apps/com.bankcomm.Bankcomm.ts)

## 首页弹窗广告

默认禁用 - 点击右上角x

- [快照-0](https://i.gkd.li/import/12671987)
- [快照-1](https://i.gkd.li/import/12745293)

## 版本升级弹窗

默认禁用 - 点击 暂不更新

- [快照-0](https://i.gkd.li/import/12842484)
