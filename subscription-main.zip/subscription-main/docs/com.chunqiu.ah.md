# AH视频

存在 7 规则组 - [com.chunqiu.ah](/src/apps/com.chunqiu.ah.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13264387)
- [快照-1](https://i.gkd.li/import/13264381)
- [快照-2](https://i.gkd.li/import/13264377)

## 全屏广告-弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13264383)

## 局部广告-卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/13635499)

## 全屏广告-首页推广

默认禁用 - 点击我已知晓

- [快照-0](https://i.gkd.li/import/13852430)

## 全屏广告-公告

默认禁用 - 点击不再提示

- [快照-0](https://i.gkd.li/import/13852447)

## 全屏广告-首页广告弹窗

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13852448)

## 局部广告-播放界面广告

默认禁用 - 点击X

- [快照-0](https://i.gkd.li/import/13852535)
- [快照-1](https://i.gkd.li/import/13852695)
- [快照-2](https://i.gkd.li/import/13852670)
- [快照-3](https://i.gkd.li/import/13852669)
