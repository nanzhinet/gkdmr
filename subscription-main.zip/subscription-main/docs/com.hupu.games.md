# 虎扑

存在 1 规则组 - [com.hupu.games](/src/apps/com.hupu.games.ts)

## 推荐流广告

默认禁用 - 点击卡片右上角广告文字,出现广告反馈,点击屏蔽该广告

- [快照-0](https://i.gkd.li/import/12511005)
- [快照-1](https://i.gkd.li/import/13258026)
- [快照-2](https://i.gkd.li/import/13259692)
- [快照-3](https://i.gkd.li/import/12511010)
- [快照-4](https://i.gkd.li/import/12534848)
- [快照-5](https://i.gkd.li/import/13259699)
