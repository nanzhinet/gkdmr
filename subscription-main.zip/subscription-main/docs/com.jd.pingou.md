# 京喜

存在 1 规则组 - [com.jd.pingou](/src/apps/com.jd.pingou.ts)

## 底部申请定位浮窗

默认禁用

- [快照-0](https://i.gkd.li/import/13804515)
