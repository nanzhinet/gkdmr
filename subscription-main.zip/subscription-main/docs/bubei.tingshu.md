# 懒人听书

存在 2 规则组 - [bubei.tingshu](/src/apps/bubei.tingshu.ts)

## 悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/13348489)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13545953)
