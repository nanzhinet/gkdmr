# 文心一言

存在 1 规则组 - [com.baidu.newapp](/src/apps/com.baidu.newapp.ts)

## 升级提示

默认禁用

- [快照-0](https://i.gkd.li/import/13360280)
