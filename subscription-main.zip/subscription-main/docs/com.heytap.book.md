# 书城

存在 1 规则组 - [com.heytap.book](/src/apps/com.heytap.book.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13255499)
