# 动卡空间

存在 3 规则组 - [com.citiccard.mobilebank](/src/apps/com.citiccard.mobilebank.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12684908)
- [快照-1](https://i.gkd.li/import/13049013)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13049284)

## 通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13049283)
