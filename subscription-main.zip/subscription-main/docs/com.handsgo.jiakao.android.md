# 驾考宝典

存在 4 规则组 - [com.handsgo.jiakao.android](/src/apps/com.handsgo.jiakao.android.ts)

## 开屏广告

## 悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/13475994)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13476039)
- [快照-1](https://i.gkd.li/import/13523033)

## 请求开启通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13520296)
