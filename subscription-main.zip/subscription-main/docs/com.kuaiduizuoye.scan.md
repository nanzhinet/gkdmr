# 快对

存在 1 规则组 - [com.kuaiduizuoye.scan](/src/apps/com.kuaiduizuoye.scan.ts)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12716285)
