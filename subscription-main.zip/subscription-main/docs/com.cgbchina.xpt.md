# 广发银行

存在 1 规则组 - [com.cgbchina.xpt](/src/apps/com.cgbchina.xpt.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13189690)
