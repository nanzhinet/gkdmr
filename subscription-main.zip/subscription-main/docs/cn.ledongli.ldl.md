# 乐动力

存在 1 规则组 - [cn.ledongli.ldl](/src/apps/cn.ledongli.ldl.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12668468)
- [快照-1](https://i.gkd.li/import/13259199)
