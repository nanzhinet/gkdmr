# 小度

存在 1 规则组 - [com.baidu.duer.superapp](/src/apps/com.baidu.duer.superapp.ts)

## 开屏广告

- [示例-0](https://github.com/gkd-kit/inspect/assets/38517192/5f6591b6-220e-4117-9cc1-b07375085f64)

- [快照-0](https://i.gkd.li/import/13310527)
- [快照-1](https://i.gkd.li/import/12506571)
