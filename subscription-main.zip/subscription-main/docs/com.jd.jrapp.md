# 京东金融

存在 3 规则组 - [com.jd.jrapp](/src/apps/com.jd.jrapp.ts)

## 通知提醒

默认禁用

- [快照-0](https://i.gkd.li/import/13249998)
- [快照-1](https://i.gkd.li/import/13255656)

## 版本更新

默认禁用

- [快照-0](https://i.gkd.li/import/13628364)

## 满意度打分弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13804561)
