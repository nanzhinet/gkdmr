# 动漫之家

存在 2 规则组 - [com.dmzj.manhua](/src/apps/com.dmzj.manhua.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13542503)

## 主页-浮窗

默认禁用 - 浮窗-您想运行会员系统吗？

- [快照-0](https://i.gkd.li/import/13542506)
