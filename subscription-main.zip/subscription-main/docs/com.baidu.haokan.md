# 好看视频

存在 1 规则组 - [com.baidu.haokan](/src/apps/com.baidu.haokan.ts)

## 青少年模式弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13498610)
