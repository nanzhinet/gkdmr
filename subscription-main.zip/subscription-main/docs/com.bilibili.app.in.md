# bilibili

存在 4 规则组 - [com.bilibili.app.in](/src/apps/com.bilibili.app.in.ts)

## 评论区-满意度评价

默认禁用

- [快照-0](https://i.gkd.li/import/13115189)

## APP评分

默认禁用

- [快照-0](https://i.gkd.li/import/13180746)

## 订阅感兴趣的通知

默认禁用 - 点击【暂不开启】

- [快照-0](https://i.gkd.li/import/13399195)

## 打开推送通知弹窗

默认禁用 - 自动点击“暂不”

- [快照-0](https://i.gkd.li/import/13600976)
