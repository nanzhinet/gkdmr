# 搜书大师

存在 1 规则组 - [com.flyersoft.seekbooks](/src/apps/com.flyersoft.seekbooks.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12857275)
- [快照-1](https://i.gkd.li/import/13797352)
