# 简单搜索

存在 1 规则组 - [com.baidu.searchcraft](/src/apps/com.baidu.searchcraft.ts)

## 信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/13520385)
