# 中国移动

存在 6 规则组 - [com.greenpoint.android.mc10086.activity](/src/apps/com.greenpoint.android.mc10086.activity.ts)

## 关闭更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12534264)

## 首页广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12662361)

## 请求推送通知弹窗

默认禁用 - 请求推送通知弹窗，点击取消

- [快照-0](https://i.gkd.li/import/12662213)
- [快照-1](https://i.gkd.li/import/13327880)
- [快照-2](https://i.gkd.li/import/13775652)

## 请求获取剪贴板权限弹窗

默认禁用 - 请求获取剪贴板权限弹窗，点击不允许

- [快照-0](https://i.gkd.li/import/12662251)
- [快照-1](https://i.gkd.li/import/13775651)

## 右侧悬浮小图标

默认禁用

- [快照-0](https://i.gkd.li/import/12662265)

## 请求好评弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12662345)
