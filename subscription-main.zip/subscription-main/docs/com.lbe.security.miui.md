# 权限管理服务

存在 1 规则组 - [com.lbe.security.miui](/src/apps/com.lbe.security.miui.ts)

## 权限授予弹窗

默认禁用 - 自动点击【仅在使用中允许】

- [快照-0](https://i.gkd.li/import/13761264)
