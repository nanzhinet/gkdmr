# 小布助手

存在 1 规则组 - [com.heytap.speechassist](/src/apps/com.heytap.speechassist.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13626895)
