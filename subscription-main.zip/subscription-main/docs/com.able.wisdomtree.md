# 知到

存在 2 规则组 - [com.able.wisdomtree](/src/apps/com.able.wisdomtree.ts)

## 消息推送通知

默认禁用 - 自动点击暂不开启。

- [快照-0](https://i.gkd.li/import/13458779)
- [快照-1](https://i.gkd.li/import/13623441)
- [快照-2](https://i.gkd.li/import/13695447)

## 升级提醒

默认禁用 - 自动点击忽略。

- [快照-0](https://i.gkd.li/import/13458796)
- [快照-1](https://i.gkd.li/import/13797285)
