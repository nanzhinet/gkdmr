# 游民星空

存在 1 规则组 - [com.gamersky](/src/apps/com.gamersky.ts)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/13451220)
- [快照-1](https://i.gkd.li/import/13635580)
- [快照-2](https://i.gkd.li/import/13451258)
- [快照-3](https://i.gkd.li/import/13635579)
- [快照-4](https://i.gkd.li/import/13759484)
