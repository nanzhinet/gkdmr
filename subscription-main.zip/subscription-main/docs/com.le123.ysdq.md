# 影视大全

存在 1 规则组 - [com.le123.ysdq](/src/apps/com.le123.ysdq.ts)

## 卡片式广告

默认禁用

- [快照-0](https://i.gkd.li/import/13635244)
