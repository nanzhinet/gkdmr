# 趣智校园

存在 2 规则组 - [com.klcxkj.zqxy](/src/apps/com.klcxkj.zqxy.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13195649)
- [快照-1](https://i.gkd.li/import/12781415)
- [快照-2](https://i.gkd.li/import/12781461)
- [快照-3](https://i.gkd.li/import/13488673)
- [快照-4](https://i.gkd.li/import/13546464)
- [快照-5](https://i.gkd.li/import/13071301)
- [快照-6](https://i.gkd.li/import/13274836)
- [快照-7](https://i.gkd.li/import/13274836)
- [快照-8](https://i.gkd.li/import/13707849)
- [快照-9](https://i.gkd.li/import/13274838)

## 横幅广告

默认禁用

- [快照-0](https://i.gkd.li/import/13488870)
