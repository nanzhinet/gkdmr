# Gspace

存在 2 规则组 - [com.gspace.android](/src/apps/com.gspace.android.ts)

## 主页面上方广告

默认禁用

- [快照-0](https://i.gkd.li/import/12705339)
- [快照-1](https://i.gkd.li/import/12910419)
- [快照-2](https://i.gkd.li/import/12910935)
- [快照-3](https://i.gkd.li/import/12910420)

## Youtube播放视频跳过广告

默认禁用

- [快照-0](https://i.gkd.li/import/12709006)
