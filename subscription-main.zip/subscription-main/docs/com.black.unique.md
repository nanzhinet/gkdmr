# 全球购骑士特权

存在 1 规则组 - [com.black.unique](/src/apps/com.black.unique.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13499502)
