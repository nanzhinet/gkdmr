# 央视体育

存在 1 规则组 - [com.cctv.cctv5ultimate](/src/apps/com.cctv.cctv5ultimate.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13405159)
