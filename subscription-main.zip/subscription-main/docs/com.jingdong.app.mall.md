# 京东

存在 10 规则组 - [com.jingdong.app.mall](/src/apps/com.jingdong.app.mall.ts)

## 购物车界面-砸金蛋

默认禁用

- [快照-0](https://i.gkd.li/import/12642266)

## 我的界面-悬浮广告

默认禁用

- [快照-0](https://i.gkd.li/import/12642270)
- [快照-1](https://i.gkd.li/import/12774910)
- [快照-2](https://i.gkd.li/import/13242002)

## 首页-右侧浮层广告

默认禁用

- [快照-0](https://i.gkd.li/import/13165659)
- [快照-1](https://i.gkd.li/import/12837870)
- [快照-2](https://i.gkd.li/import/13072091)
- [快照-3](https://i.gkd.li/import/12837870)

## 通知提示-请求打开通知

默认禁用

- [快照-0](https://i.gkd.li/import/12839864)
- [快照-1](https://i.gkd.li/import/13772299)
- [快照-2](https://i.gkd.li/import/13917163)
- [快照-3](https://i.gkd.li/import/12839865)

## 广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13165721)
- [快照-1](https://i.gkd.li/import/13218034)
- [快照-2](https://i.gkd.li/import/13241883)
- [快照-3](https://i.gkd.li/import/132599029)
- [快照-4](https://i.gkd.li/import/13258996)
- [快照-5](https://i.gkd.li/import/13336847)

## 首页-底部横幅广告

默认禁用

- [快照-0](https://i.gkd.li/import/13258973)
- [快照-1](https://i.gkd.li/import/13258980)
- [快照-2](https://i.gkd.li/import/13258981)

## 首页弹窗-打开通知

默认禁用 - 自动点击正下方的【x】

- [快照-0](https://i.gkd.li/import/13463618)

## 京东账号登录授权

默认禁用 - 自动点击【确认登录】

- [快照-0](https://i.gkd.li/import/12901734)

## 支付界面-产品推荐

默认禁用 - 自动点击右上角【x】

- [快照-0](https://i.gkd.li/import/13191146)

## 购物车界面-支付成功广告弹窗

默认禁用 - 自动点击正下方的【x】

- [快照-0](https://i.gkd.li/import/13446362)
