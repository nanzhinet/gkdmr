# Gmail

存在 1 规则组 - [com.google.android.gm](/src/apps/com.google.android.gm.ts)

## 信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/13255698)
- [快照-1](https://i.gkd.li/import/13255698)
- [快照-2](https://i.gkd.li/import/13255700)
- [快照-3](https://i.gkd.li/import/13724271)
- [快照-4](https://i.gkd.li/import/13255701)
- [快照-5](https://i.gkd.li/import/13724287)
- [快照-6](https://i.gkd.li/import/13263279)
