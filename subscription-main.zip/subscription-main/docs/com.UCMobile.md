# UC浏览器

存在 4 规则组 - [com.UCMobile](/src/apps/com.UCMobile.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13188653)
- [快照-1](https://i.gkd.li/import/13197655)

## 信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/12880737)
- [快照-1](https://i.gkd.li/import/12881751)
- [快照-2](https://i.gkd.li/import/12880772)
- [快照-3](https://i.gkd.li/import/12881307)

## 请求通知权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12880812)
- [快照-1](https://i.gkd.li/import/12880802)

## 请求添加桌面快捷方式权限弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12880983)
