# 贴吧一键签到大师

存在 1 规则组 - [com.baidutieba.davy](/src/apps/com.baidutieba.davy.ts)

## 内部弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12504289)
- [快照-1](https://i.gkd.li/import/12504291)
