# 京东读书

存在 3 规则组 - [com.jd.app.reader](/src/apps/com.jd.app.reader.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12686632)

## 首页弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/12686577)
- [快照-1](https://i.gkd.li/import/12686664)

## 阅读页面广告弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/12881810)
- [快照-1](https://i.gkd.li/import/12893631)
