# youtube

存在 4 规则组 - [com.google.android.youtube](/src/apps/com.google.android.youtube.ts)

## 视频播放-跳过广告

默认禁用

- [快照-0](https://i.gkd.li/import/13797491)
- [快照-1](https://i.gkd.li/import/12565261)
- [快照-2](https://i.gkd.li/import/13705106)

## 视频播放-赞助商广告

默认禁用

- [快照-0](https://i.gkd.li/import/12877346)
- [快照-1](https://i.gkd.li/import/13797491)
- [快照-2](https://i.gkd.li/import/13705106)

## 首页-会员广告

默认禁用

- [快照-0](https://i.gkd.li/import/12877357)

## 订阅浮窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13797512)
