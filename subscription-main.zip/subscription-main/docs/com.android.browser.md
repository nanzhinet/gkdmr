# 小米浏览器

存在 2 规则组 - [com.android.browser](/src/apps/com.android.browser.ts)

## 关闭[个性推荐开启提示]

默认禁用

- [快照-0](https://i.gkd.li/import/12829403)

## 主页信息流广告

默认禁用

- [快照-0](https://i.gkd.li/import/12894221)
- [快照-1](https://i.gkd.li/import/12893649)
- [快照-2](https://i.gkd.li/import/12894234)
- [快照-3](https://i.gkd.li/import/13196059)
