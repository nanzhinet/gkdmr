# 毒霸姬

存在 1 规则组 - [com.cf.dubaji](/src/apps/com.cf.dubaji.ts)

## 更新弹窗

默认禁用

- [快照-0](https://i.gkd.li/import/13198107)
