# 华为视频

存在 1 规则组 - [com.huawei.himovie](/src/apps/com.huawei.himovie.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12814007)
- [快照-1](https://i.gkd.li/import/12819351)
