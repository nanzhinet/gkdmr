# 荣耀智慧空间

存在 3 规则组 - [com.hihonor.magichome](/src/apps/com.hihonor.magichome.ts)

## 首页顶部广告

默认禁用

- [快照-0](https://i.gkd.li/import/12843930)

## 推荐服务声明

默认禁用 - 推荐服务声明弹窗。默认点击【取消】按钮

- [快照-0](https://i.gkd.li/import/12843976)

## 升级提示

默认禁用 - 点击以后再说

- [快照-0](https://i.gkd.li/import/12916700)
