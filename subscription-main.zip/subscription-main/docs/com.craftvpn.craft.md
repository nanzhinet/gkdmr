# 小牛加速器

存在 1 规则组 - [com.craftvpn.craft](/src/apps/com.craftvpn.craft.ts)

## 开屏广告

点击X

- [快照-0](https://i.gkd.li/import/13914788)
