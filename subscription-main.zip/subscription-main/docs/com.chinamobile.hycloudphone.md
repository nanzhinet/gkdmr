# 移动云手机

存在 1 规则组 - [com.chinamobile.hycloudphone](/src/apps/com.chinamobile.hycloudphone.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/13227571)
