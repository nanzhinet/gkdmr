# 春木漫画

存在 1 规则组 - [com.galaxy.qbyd](/src/apps/com.galaxy.qbyd.ts)

## 弹窗广告

默认禁用

- [快照-0](https://i.gkd.li/import/13691104)
- [快照-1](https://i.gkd.li/import/13691103)
