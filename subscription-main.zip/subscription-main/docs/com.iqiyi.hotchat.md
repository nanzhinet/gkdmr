# 爱奇艺热聊

存在 1 规则组 - [com.iqiyi.hotchat](/src/apps/com.iqiyi.hotchat.ts)

## 开屏广告
