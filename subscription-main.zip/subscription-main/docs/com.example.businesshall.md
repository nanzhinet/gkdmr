# 中国移动浙江

存在 1 规则组 - [com.example.businesshall](/src/apps/com.example.businesshall.ts)

## 开屏广告

- [快照-0](https://i.gkd.li/import/12830978)
